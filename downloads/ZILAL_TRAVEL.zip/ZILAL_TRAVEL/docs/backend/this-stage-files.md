# Новые файлы: английская версия и эксплуатация

- `backend/app/mail.py`
- `backend/app/maintenance.py`
- `backend/app/operations.py`
- `backend/app/payment_links.py`
- `backend/app/translation_seed.py`
- `backend/app/worker.py`
- `backend/migrations/versions/703c6d63a6ff_english_contact_address.py`
- `backend/migrations/versions/8840f89ec4f9_published_translations_and_english_site_.py`
- `backend/migrations/versions/d312814f27fe_private_bank_transfer_links.py`
- `backend/migrations/versions/f9d5f891c18b_operational_status_and_transactional_.py`
- `backend/tests/test_operations.py`
- `backend/tools/register-worker.ps1`
- `backend/tools/start-worker.ps1`
- `docs/backend/operations.md`
- `docs/backend/this-stage-files.md`
- `frontend/app/(public)/payment/page.tsx`
- `frontend/components/localization/LocaleProvider.tsx`
- `frontend/components/public/Payment.tsx`
- `frontend/components/server/Operations.tsx`
- `frontend/components/server/PaymentLink.tsx`
- `frontend/data/content/en-platform.ts`
- `frontend/data/content/examples-en.json`
- `frontend/data/localized.ts`
- `frontend/proxy.ts`

Изменены также существующие публичные компоненты, настройки админки, серверные схемы/API, CLI и инструкции. Новых зависимостей приложения нет.
