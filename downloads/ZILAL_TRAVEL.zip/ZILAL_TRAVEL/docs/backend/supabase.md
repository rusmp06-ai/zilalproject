# Supabase для ZILAL TRAVEL

Подготовлено подключение существующего Python API к PostgreSQL Supabase и приватному Storage. Сайт пока не опубликован; Supabase не размещает наш Python API и Next.js. Можно сначала запускать их на вашем Windows, а данные и серверные фото будут храниться в Supabase.

## 1. Создать проект без оплаты

Откройте https://supabase.com/dashboard, создайте организацию и **новый отдельный проект** на плане Free. Для начала достаточно одного проекта. Не подключайте платные расширения. Придумайте и сохраните пароль базы. Лимиты Storage, базы, трафика и условия приостановки неактивного проекта проверьте в текущем Dashboard/https://supabase.com/pricing; бесплатный тариф не означает неограниченное хранилище или гарантированную круглосуточную работу.

## 2. Подключить базу

В Dashboard нажмите **Connect → Session pooler** и скопируйте строку подключения PostgreSQL (порт 5432). Для Windows и IPv4 это обычно доступнее прямого IPv6 подключения. Transaction pooler (6543) для этой конфигурации не используйте. Подставьте пароль базы; специальные символы пароля должны быть URL-кодированы. SQLAlchemy принимает скопированный префикс `postgresql://` — проект сам выбирает psycopg.

Скачайте корневой сертификат базы в **Database settings** и добавьте к строке параметры `sslmode=verify-full&sslrootcert=C:/Users/777/supabase-ca.crt`, указав действительный путь к сертификату. Это включает шифрование и проверку сервера. Не отключайте TLS и проверку сертификата для обхода ошибок. См. официальную [инструкцию подключения](https://supabase.com/docs/guides/database/connecting-to-postgres).

Из корня распакованного проекта в PowerShell:

```powershell
Copy-Item backend\.env.example backend\.env
notepad backend\.env
```

Если `backend/.env` уже существует, откройте его и измените нужные строки; не заменяйте рабочую конфигурацию примером.

Задайте в **backend/.env**, сохраняя секретные значения только у себя:

```dotenv
DATABASE_URL=postgresql://postgres.PROJECT_REF:YOUR_URL_ENCODED_PASSWORD@YOUR_SESSION_POOLER_HOST:5432/postgres?sslmode=verify-full&sslrootcert=C:/Users/777/supabase-ca.crt
SITE_ORIGIN=http://localhost:3000
APP_ENV=development
MEDIA_STORAGE=supabase
SUPABASE_URL=https://YOUR_PROJECT_REF.supabase.co
SUPABASE_SERVICE_KEY=YOUR_LEGACY_SERVICE_ROLE_KEY
SUPABASE_STORAGE_BUCKET=zilal-media
BACKUP_DRIVER=pg_dump
MAIL_ENABLED=false
```

`DATABASE_URL` и `SUPABASE_SERVICE_KEY` — секреты. Не присылайте их в чат, не загружайте в GitHub и не добавляйте в `NEXT_PUBLIC_*`. Для работы агента в облачной среде задавайте их через защищённые настройки среды. `.env` исключены из Git и скачиваемого архива.

## 3. Настроить фотографии

В Supabase **Storage → New bucket** создайте **zilal-media**. **Public bucket выключен**. Разрешённый тип — `image/webp`, максимальный размер объекта — 32 МБ (обычный входящий файл в админке ограничен 8 МБ и 25 мегапикселями).

В **Project settings → API keys → Legacy API keys** скопируйте **service_role** в `SUPABASE_SERVICE_KEY` на сервере. Это не `anon`/publishable key. Storage работает только через наш API; браузеру этот ключ не передаётся. Public-политики на bucket не нужны.

Сервер проверяет файл, исправляет ориентацию, удаляет EXIF, создаёт WebP до 2560 пикселей с quality 85 и сохраняет его в Storage. Это серверная обработка для публичного сайта. Локальное demo продолжает сохранять оригиналы в IndexedDB. Старые серверные фотографии на диске не перемещаются автоматически; для каждой записи запоминается её хранилище.

## 4. Создать таблицы и владельца

Установите Python 3.12+ с https://www.python.org/downloads/ и менеджер uv:

```powershell
py -m pip install uv
cd backend
py -m uv sync --frozen
py -m uv run --frozen alembic upgrade head
py -m uv run --frozen python -m app.cli create-user --email "ВАШ_EMAIL" --name "Владелец"
```

Последняя команда попросит пароль дважды, не выводя его. Используйте свой email вместо `ВАШ_EMAIL`. Это аккаунт админки ZILAL, он отдельный от аккаунта Dashboard Supabase.

Миграции автоматически включают RLS и убирают доступ ролей `anon`, `authenticated`, `service_role` к **таблицам нашего приложения** в public: CRM, сессиям, пользователям и контенту. Доступ через наш авторизованный API сохраняется. Таблицы Supabase `auth`/`storage` не меняются. Для повторной проверки после миграций:

```powershell
py -m uv run --frozen python -m app.cli secure-supabase
```

Без `--apply` это проверка с откатом. Для сохранения — `secure-supabase --apply`. Новые миграции выполняйте с учётной записью владельца базы/таблиц из Connect, а не с браузерным API-ключом.

## 5. Перенести контент и фото из локального демо

До переключения сохраните **Настройки → Экспорт JSON** в старой админке. Новая версия экспортирует фотографии внутри файла. Самих ссылок `local-photo:...` недостаточно — они существуют только в конкретном браузере.

Из папки backend:

```powershell
py -m uv run --frozen python -m app.cli import-content "C:\Users\777\Downloads\zilal-local-data.json"
```

Это предварительная проверка: транзакция откатывается, файлы в Supabase не загружаются. Если проверка прошла:

```powershell
py -m uv run --frozen python -m app.cli import-content "C:\Users\777\Downloads\zilal-local-data.json" --apply
```

Импорт до 100 МБ поддерживает встроенные JPG/PNG/WebP: они проходят серверную обработку и загружаются в выбранное хранилище, а контент получает адреса `/api/media/UUID`. Одинаковые фото внутри одного импорта не дублируются. Существующие ID/slug пропускаются без перезаписи; фиктивные CRM-записи/сотрудники не импортируются. Повторный импорт не обновляет уже существующие туры. Если прежние примеры уже импортированы, меняйте их через админку.

Для чистой базы вместо своего экспорта можно импортировать `initial-content.json`; это публичные примеры, а не реальные отзывы/предложения.

## 6. Запустить сайт с общей базой

В первом окне PowerShell из backend:

```powershell
py -m uv run --frozen uvicorn app.main:app --host 127.0.0.1 --port 8000
```

Во втором окне перейдите в папку frontend, создайте/откройте `.env.local` и задайте:

```dotenv
PLATFORM_MODE=server
BACKEND_URL=http://127.0.0.1:8000
SITE_ORIGIN=http://localhost:3000
INDEXING_ENABLED=false
```

Затем:

```powershell
npm.cmd ci
npm.cmd run dev
```

Откройте http://localhost:3000/login, войдите созданным email/паролем. После входа доступна `/admin`. Согласуйте порт 3000 и `SITE_ORIGIN` в обоих файлах. Если запущено другое окно с прежним демо, сначала остановите его через Ctrl+C.

## Резервные копии и восстановление

На Free не рассчитывайте на автоматическую резервную копию Supabase. Наш worker сохраняет отдельный ZIP с дампом **public** и фото с диска и Supabase, проверяет SHA-256 и только после успеха удаляет старые копии. При недоступной фотографии полная копия не считается успешной. Установите PostgreSQL client (`pg_dump` совместимой версии с сервером), настройте `PG_DUMP_PATH` и запустите worker по [инструкции эксплуатации](operations.md). Сам ZIP храните отдельно от публичного bucket/репозитория. Проверка архива: `python -m app.cli verify-backup ПУТЬ`.

При восстановлении кроме дампа базы нужно восстановить файлы `media/*.webp`: для строк `media.storage_driver=supabase` загрузите их в тот же приватный bucket **с исходными именами UUID.webp**; для `local` — в `MEDIA_ROOT`. Один дамп PostgreSQL фотографии не восстанавливает. Перед заменой действующей базы проверьте восстановление в отдельной базе/проекте.

## Что пока не выполнено

Проверено: 57 backend-тестов на локальной PostgreSQL, включая REST-контракт Supabase с имитацией ответов, RLS/права реальной PostgreSQL, импорт фотографий без записи при предварительной проверке и полные резервные копии. Новых зависимостей не добавлено. Реальное соединение с вашим Supabase, bucket, ограничения тарифа и восстановление в нём проверить можно только после создания проекта и настройки секретов. Подключение Supabase не публикует сайт.
