# Creates a task for the CURRENT Windows user, triggered at sign-in. Run once.
$ErrorActionPreference = 'Stop'
$workerScript = Join-Path $PSScriptRoot 'start-worker.ps1'
$workerShell = (Get-Command powershell.exe -ErrorAction Stop).Source
$workerAction = New-ScheduledTaskAction -Execute $workerShell -Argument ('-NoProfile -File "' + $workerScript + '"')
$workerTrigger = New-ScheduledTaskTrigger -AtLogOn -User ([System.Security.Principal.WindowsIdentity]::GetCurrent().Name)
$workerSettings = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -ExecutionTimeLimit ([TimeSpan]::Zero) -RestartCount 3 -RestartInterval (New-TimeSpan -Minutes 1) -MultipleInstances IgnoreNew
Register-ScheduledTask -TaskName 'ZILAL maintenance' -Action $workerAction -Trigger $workerTrigger -Settings $workerSettings -Description 'ZILAL: резервные копии, очистка сессий, почтовая очередь' -Force | Out-Null
Start-ScheduledTask -TaskName 'ZILAL maintenance'
Write-Output 'Задание создано для текущего пользователя. Docker должен быть запущен. Проверяйте состояние в админке → Настройки.'
