# Run from any folder. The worker reads backend/.env; no passwords in this script.
$ErrorActionPreference = 'Stop'
Set-Location (Split-Path $PSScriptRoot -Parent)
$workerPython = Join-Path (Get-Location) '.venv\Scripts\python.exe'
if (-not (Test-Path $workerPython)) { throw 'Сначала выполните py -m uv sync --frozen в папке backend.' }
& $workerPython -m app.worker
if ($LASTEXITCODE -ne 0) { throw 'Фоновое обслуживание остановилось. Проверьте базу и настройки backend/.env.' }
