import io
import json
from urllib.error import HTTPError
from uuid import uuid4

import pytest
from fastapi import HTTPException
from PIL import Image
from pydantic import SecretStr, ValidationError
from sqlalchemy import select

from app.config import Config, config
from app.database import SessionLocal
from app.maintenance import create_backup, verify_backup
from app.media_storage import NoRedirect, supabase_request
from app.models import Media

BASE = "/api/v1"


def photo():
    buffer = io.BytesIO()
    Image.new("RGB", (80, 60), "blue").save(buffer, "PNG")
    return buffer.getvalue()


@pytest.fixture
def cloud(monkeypatch):
    cfg = config()
    monkeypatch.setattr(cfg, "media_storage", "supabase")
    monkeypatch.setattr(cfg, "supabase_url", "https://example.supabase.co")
    monkeypatch.setattr(cfg, "supabase_service_key", SecretStr("test-private-service-key"))
    objects, calls = {}, []

    class Opener:
        def open(self, request, timeout):
            calls.append((request.method, request.full_url))
            assert request.get_header("Authorization") == "Bearer test-private-service-key"
            assert request.get_header("Apikey") == "test-private-service-key"
            name = request.full_url.rsplit("/", 1)[1]
            if request.method == "POST":
                assert request.get_header("X-upsert") == "false"
                objects[name] = request.data
                return io.BytesIO(b"{}")
            if request.method == "DELETE":
                assert request.full_url.endswith("/object/zilal-media")
                assert request.get_header("Content-type") == "application/json"
                name = json.loads(request.data)["prefixes"][0]
                objects.pop(name, None)
                return io.BytesIO(b"{}")
            if name not in objects:
                raise HTTPError(request.full_url, 404, "missing", {}, None)
            assert "/object/authenticated/zilal-media/" in request.full_url
            return io.BytesIO(objects[name])

    monkeypatch.setattr("app.media_storage.build_opener", lambda *args: Opener())
    return objects, calls


def test_supabase_upload_read_and_delete_keep_existing_disk_photos(authorized, cloud, monkeypatch):
    client, headers = authorized
    objects, calls = cloud
    cfg = config()
    monkeypatch.setattr(cfg, "media_storage", "local")
    local = client.post(BASE + "/admin/media", headers=headers, content=photo()).json()
    monkeypatch.setattr(cfg, "media_storage", "supabase")
    monkeypatch.setattr(cfg, "app_env", "production")
    uploaded = client.post(BASE + "/admin/media", headers=headers, content=photo())
    assert uploaded.status_code == 201
    item = uploaded.json()
    assert len(objects) == 1 and "test-private" not in uploaded.text
    with SessionLocal() as db:
        assert db.get(Media, item["id"]).storage_driver == "supabase"
        assert db.get(Media, local["id"]).storage_driver == "local"
    assert client.get(BASE + "/public/media/" + item["id"]).content == objects[item["id"] + ".webp"]
    monkeypatch.setattr(cfg, "app_env", "development")
    assert client.get(BASE + "/public/media/" + local["id"]).status_code == 200
    assert client.delete(BASE + "/admin/media/" + item["id"], headers=headers).status_code == 200
    assert not objects
    assert [c[0] for c in calls] == ["POST", "GET", "DELETE"]


def test_cloud_failure_does_not_register_a_photo_or_leak_key(authorized, monkeypatch):
    client, headers = authorized
    monkeypatch.setattr(config(), "media_storage", "supabase")
    monkeypatch.setattr(config(), "supabase_url", "")
    response = client.post(BASE + "/admin/media", headers=headers, content=photo())
    assert response.status_code == 503
    with SessionLocal() as db:
        assert not list(db.scalars(select(Media)))


def test_supabase_backup_includes_remote_bytes(tmp_path, monkeypatch, authorized, cloud):
    client, headers = authorized
    item = client.post(BASE + "/admin/media", headers=headers, content=photo()).json()
    monkeypatch.setattr(config(), "backup_root", str(tmp_path / "backup"))
    monkeypatch.setattr(
        "app.maintenance.dump_database", lambda p: p.write_bytes(b"private db fixture")
    )
    with SessionLocal() as db:
        name = create_backup(db)
        db.commit()
    manifest = verify_backup(tmp_path / "backup" / name)
    assert "media/" + item["id"] + ".webp" in manifest["files"]
    cloud[0].clear()
    with SessionLocal() as db, pytest.raises(HTTPException):
        create_backup(db)
    assert len(list((tmp_path / "backup").glob("*.zip"))) == 1


def test_supabase_credentials_cannot_follow_redirects_and_failures_are_generic(monkeypatch):
    assert NoRedirect().redirect_request(None, None, 302, "", {}, "https://elsewhere.test") is None
    monkeypatch.setattr(config(), "supabase_url", "https://example.supabase.co")
    monkeypatch.setattr(config(), "supabase_service_key", SecretStr("private-value"))

    class Failure:
        def open(self, *args, **kwargs):
            raise HTTPError("private-value", 403, "private-value", {}, None)

    monkeypatch.setattr("app.media_storage.build_opener", lambda *args: Failure())
    with pytest.raises(HTTPException) as error:
        supabase_request("GET", str(uuid4()) + ".webp")
    assert error.value.status_code == 503 and "private-value" not in error.value.detail


def test_supabase_config_accepts_dashboard_url_and_rejects_unsafe_endpoints():
    cfg = Config(_env_file=None, database_url="postgresql://user:password@localhost/db")
    assert cfg.database_url.startswith("postgresql+psycopg://")
    for url in (
        "http://example.supabase.co",
        "https://example.supabase.co/other",
        "https://elsewhere.test",
    ):
        with pytest.raises(ValidationError):
            Config(_env_file=None, database_url=cfg.database_url, supabase_url=url)


def test_demo_photo_import_is_dry_until_apply_and_deduplicates(cloud):
    import base64

    from app.photo_import import PhotoImport

    source = "data:image/png;base64," + base64.b64encode(photo()).decode()
    with SessionLocal() as db:
        batch = PhotoImport(db)
        url = batch.image(source)
        assert batch.image(source) == url
        assert not cloud[0]  # Validation and database preview never upload a file.
        assert len(list(db.scalars(select(Media)))) == 1
        db.rollback()
    with SessionLocal() as db:
        assert not list(db.scalars(select(Media)))
        batch = PhotoImport(db)
        batch.image(source)
        batch.upload()
        assert len(cloud[0]) == 1
        db.rollback()
        batch.cleanup()
        assert not cloud[0]
    with SessionLocal() as db:
        with pytest.raises(ValueError, match="Экспортируйте JSON"):
            PhotoImport(db).image("local-photo:" + str(uuid4()))


def test_application_tables_are_private_without_changing_supabase_owned_tables():
    from sqlalchemy import text
    from sqlalchemy.exc import DBAPIError

    from app.models import Base
    from app.supabase_setup import secure_tables

    with SessionLocal() as db:
        # Transactional roles/schemas are rolled back: the test never changes the cluster persistently.
        roles = set(db.scalars(text("SELECT rolname FROM pg_roles")))
        for role in ("anon", "authenticated", "service_role"):
            if role not in roles:
                db.execute(text(f'CREATE ROLE "{role}" NOLOGIN'))
        db.execute(text("CREATE SCHEMA IF NOT EXISTS storage"))
        db.execute(text("CREATE TABLE storage.zilal_test_fixture (id integer)"))
        db.execute(text('GRANT SELECT ON public.content TO "anon"'))
        assert secure_tables(db) == len(Base.metadata.tables) + 1
        assert db.scalar(
            text("SELECT relrowsecurity FROM pg_class WHERE oid='public.users'::regclass")
        )
        assert not db.scalar(text("SELECT has_table_privilege('anon','public.content','SELECT')"))
        assert not db.scalar(
            text(
                "SELECT relrowsecurity FROM pg_class WHERE oid='storage.zilal_test_fixture'::regclass"
            )
        )
        # The backend table owner can still access its own data.
        assert db.scalar(text("SELECT count(*) FROM public.users")) == 5
        with pytest.raises(DBAPIError), db.begin_nested():
            db.execute(text("SET LOCAL ROLE anon"))
            db.execute(text("SELECT * FROM public.users"))
        db.rollback()
