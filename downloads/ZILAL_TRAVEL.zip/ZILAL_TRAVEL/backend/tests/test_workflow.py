import io
from datetime import timedelta
from uuid import uuid4

from conftest import PASSWORD
from PIL import Image
from sqlalchemy import select

from app.auth import digest
from app.database import SessionLocal
from app.models import AccessToken, CRMEntry, LeadReceipt, User, now

BASE = "/api/v1"
ORIGIN = {"Origin": "http://testserver"}


def item(id, title, status, fields):
    return dict(
        id=id,
        slug=id,
        title=title,
        status=status,
        fields=fields,
        image="/images/lake.svg",
        description="",
    )


def login(client, role):
    r = client.post(
        BASE + "/auth/login",
        headers=ORIGIN,
        json={"email": role + "@example.com", "password": PASSWORD},
    )
    assert r.status_code == 200
    return {**ORIGIN, "X-CSRF-Token": r.json()["csrf"]}


def create(client, headers, entity, row):
    r = client.post(BASE + "/admin/crm/" + entity, headers=headers, json=row)
    assert r.status_code == 201, r.text
    return r.json()


def fixtures(client, headers):
    customer = create(
        client,
        headers,
        "customers",
        item("customer-test", "Анна", "Активный", {"email": "anna@example.com"}),
    )
    tour = client.get(BASE + "/public/tours").json()[0]
    booking = create(
        client,
        headers,
        "bookings",
        item(
            "booking-test",
            "Поездка",
            "Подтверждено",
            {
                "customer": customer["id"],
                "tour": tour["id"],
                "start": "2030-05-01",
                "people": "2",
                "amount": "1000",
                "currency": "USD",
            },
        ),
    )
    return customer, booking


def test_public_lead_private_idempotent_and_consent(client, authorized):
    _, h = authorized
    payload = {
        "key": str(uuid4()),
        "name": "Путешественник",
        "consent": True,
        "fields": {"country": "Кыргызстан", "email": "test@example.com", "people": "2"},
    }
    r = client.post(BASE + "/public/leads", json=payload, headers=ORIGIN)
    assert r.status_code == 201
    assert set(r.json()) == {"reference"}
    assert client.post(BASE + "/public/leads", json=payload, headers=ORIGIN).json() == r.json()
    assert client.get(BASE + "/public/platform").json()["collections"]["leads"] == []
    assert len(client.get(BASE + "/admin/platform").json()["collections"]["leads"]) == 1
    with SessionLocal() as db:
        assert db.scalar(select(LeadReceipt)).consent_at is not None
    payload["name"] = "Другое имя"
    assert client.post(BASE + "/public/leads", json=payload, headers=ORIGIN).status_code == 409
    payload["key"] = str(uuid4())
    payload["consent"] = False
    assert client.post(BASE + "/public/leads", json=payload, headers=ORIGIN).status_code == 422
    payload["consent"] = True
    assert client.post(BASE + "/public/leads", json=payload).status_code == 403


def test_lead_draft_tour_and_past_dates_rejected(client):
    payload = {
        "key": str(uuid4()),
        "name": "Тест",
        "consent": True,
        "fields": {"country": "KG", "email": "a@example.com", "people": "2", "tour": "missing"},
    }
    assert client.post(BASE + "/public/leads", json=payload, headers=ORIGIN).status_code == 422
    payload["fields"].update(tour="", start="2020-01-01", end="2020-01-10")
    assert client.post(BASE + "/public/leads", json=payload, headers=ORIGIN).status_code == 422
    payload["fields"].update(start="", end="", manager="invented")
    assert client.post(BASE + "/public/leads", json=payload, headers=ORIGIN).status_code == 422


def test_crm_versions_foreign_keys_and_permissions(authorized):
    client, h = authorized
    customer, booking = fixtures(client, h)
    employees = client.get(BASE + "/admin/platform").json()["collections"]["employees"]
    content_manager = next(u for u in employees if u["fields"]["role"] == "Контент-менеджер")
    invalid = {**booking, "fields": {**booking["fields"], "manager": content_manager["id"]}}
    assert (
        client.put(
            BASE + "/admin/crm/bookings/" + booking["id"], headers=h, json=invalid
        ).status_code
        == 422
    )
    update = {**customer, "title": "Изменено"}
    assert (
        client.put(
            BASE + "/admin/crm/customers/" + customer["id"], headers=h, json=update
        ).status_code
        == 200
    )
    assert (
        client.put(
            BASE + "/admin/crm/customers/" + customer["id"], headers=h, json=update
        ).status_code
        == 409
    )
    assert (
        client.delete(
            BASE + "/admin/crm/customers/" + customer["id"] + "?version=2", headers=h
        ).status_code
        == 409
    )
    assert (
        client.delete(
            BASE + "/admin/crm/bookings/" + booking["id"] + "?version=1", headers=h
        ).status_code
        == 409
    )
    mh = login(client, "manager")
    assert (
        client.post(
            BASE + "/admin/crm/payments", headers=mh, json=item("p", "Платёж", "Оплачен", {})
        ).status_code
        == 403
    )
    login(client, "content_manager")
    snapshot = client.get(BASE + "/admin/platform").json()
    assert snapshot["collections"]["customers"] == []
    assert all(a["entity"] != "customers" for a in snapshot["activity"])


def test_ledger_reconciliation_refund_immutable_currency(authorized):
    client, h = authorized
    _, booking = fixtures(client, h)
    p = item(
        "pay-test",
        "Предоплата",
        "Оплачен",
        {
            "booking": booking["id"],
            "amount": "400",
            "currency": "USD",
            "date": "2030-05-01",
            "method": "Перевод",
            "reference": "bank-001",
        },
    )
    paid = create(client, h, "payments", p)
    snap = client.get(BASE + "/admin/platform").json()
    assert snap["collections"]["bookings"][0]["fields"]["paymentStatus"] == "Частично"
    assert (
        client.put(BASE + "/admin/crm/payments/pay-test", headers=h, json=paid).status_code == 409
    )
    p.update(id="refund", slug="refund", status="Возврат")
    p["fields"].update(amount="401", reference="refund-001")
    assert client.post(BASE + "/admin/crm/payments", headers=h, json=p).status_code == 422
    p["fields"]["amount"] = "400"
    create(client, h, "payments", p)
    assert (
        client.get(BASE + "/admin/platform").json()["collections"]["bookings"][0]["fields"][
            "paymentStatus"
        ]
        == "Не оплачен"
    )
    p.update(id="bad-currency", slug="bad-currency", status="Оплачен")
    p["fields"].update(currency="EUR", reference="eur-001")
    assert client.post(BASE + "/admin/crm/payments", headers=h, json=p).status_code == 422


def test_employee_invite_reset_one_time_and_revoked_sessions(authorized):
    client, h = authorized
    payload = item(
        "new-manager",
        "Менеджер",
        "Активный",
        {"role": "Менеджер", "email": "new@example.com", "phone": ""},
    )
    r = client.post(BASE + "/admin/employees", headers=h, json=payload)
    assert r.status_code == 201, r.text
    assert "password" not in str(r.json())
    assert client.post(BASE + "/admin/employees/new-manager/invite", headers=h).status_code == 200
    link = client.post(BASE + "/admin/employees/new-manager/invite", headers=h).json()["url"]
    token = link.split("#token=")[1]
    with SessionLocal() as db:
        assert db.get(AccessToken, digest(token)) is not None
    assert (
        client.post(
            BASE + "/auth/reset-password",
            headers=ORIGIN,
            json={"token": token, "password": PASSWORD},
        ).status_code
        == 200
    )
    assert (
        client.post(
            BASE + "/auth/reset-password",
            headers=ORIGIN,
            json={"token": token, "password": PASSWORD},
        ).status_code
        == 400
    )
    r = client.post(
        BASE + "/auth/login",
        headers=ORIGIN,
        json={"email": "new@example.com", "password": PASSWORD},
    )
    assert r.status_code == 200
    mh = {**ORIGIN, "X-CSRF-Token": r.json()["csrf"]}
    assert (
        client.post(
            BASE + "/auth/change-password",
            headers=mh,
            json={"currentPassword": PASSWORD, "password": PASSWORD + "x"},
        ).status_code
        == 200
    )
    assert client.get(BASE + "/auth/me").status_code == 401


def test_employee_role_escalation_and_expired_tokens(authorized):
    client, h = authorized
    payload = item(
        "owner",
        "Владелец",
        "Активный",
        {"role": "Супер-администратор", "email": "owner@example.com"},
    )
    assert client.post(BASE + "/admin/employees", headers=h, json=payload).status_code == 403
    with SessionLocal() as db:
        user = db.scalar(select(User).where(User.role == "manager"))
        db.add(
            AccessToken(
                token_hash=digest("x" * 48),
                user_id=user.id,
                expires_at=now() - timedelta(seconds=1),
            )
        )
        db.commit()
    assert (
        client.post(
            BASE + "/auth/reset-password",
            headers=ORIGIN,
            json={"token": "x" * 48, "password": PASSWORD},
        ).status_code
        == 400
    )


def test_media_sanitized_real_image_and_validation(authorized):
    client, h = authorized
    image = Image.new("RGB", (64, 48), "blue")
    body = io.BytesIO()
    image.save(body, "PNG")
    r = client.post(BASE + "/admin/media", headers=h, content=body.getvalue())
    assert r.status_code == 201, r.text
    data = r.json()
    assert (data["width"], data["height"]) == (64, 48)
    public = client.get(BASE + "/public/media/" + data["id"])
    assert public.status_code == 200
    assert public.headers["content-type"] == "image/webp"
    assert (
        client.post(
            BASE + "/admin/media", headers=h, content=b"<svg onload='alert(1)'>"
        ).status_code
        == 422
    )
    assert client.get(BASE + "/public/media/not-an-id").status_code == 404
    assert (
        client.post(BASE + "/admin/media", headers=ORIGIN, content=body.getvalue()).status_code
        == 403
    )


def test_translation_versions_and_private_fields(authorized):
    client, h = authorized
    tour = client.get(BASE + "/public/tours").json()[0]
    path = BASE + "/admin/translations/tours/" + tour["id"] + "/en"
    assert client.get(path).status_code == 404
    payload = {
        "title": "Mountain journey",
        "description": "English translation",
        "fields": {"body": "Explore Kyrgyzstan", "itinerary": "Day 1"},
        "version": tour["version"],
    }
    r = client.put(path, headers=h, json=payload)
    assert r.status_code == 200, r.text
    assert r.json()["fields"]["itinerary"] == "Day 1"
    assert client.put(path, headers=h, json=payload).status_code == 409
    payload["version"] += 1
    payload["fields"]["amount"] = "0"
    assert client.put(path, headers=h, json=payload).status_code == 422
    russian = client.get(BASE + "/public/tours/" + tour["slug"]).json()
    assert russian["title"] == tour["title"]
    assert russian["fields"]["amount"] == tour["fields"]["amount"]


def test_public_lead_assigned_and_conversion_retries_safe(authorized):
    client, h = authorized
    payload = {
        "key": str(uuid4()),
        "name": "Новый клиент",
        "consent": True,
        "fields": {"country": "KG", "email": "convert@example.com", "people": "2"},
    }
    assert client.post(BASE + "/public/leads", headers=ORIGIN, json=payload).status_code == 201
    lead = client.get(BASE + "/admin/platform").json()["collections"]["leads"][0]
    assert lead["fields"]["manager"]
    path = BASE + "/admin/leads/" + lead["id"] + "/convert"
    first = client.post(path, headers=h, json={"version": lead["version"]})
    assert first.status_code == 200
    second = client.post(path, headers=h, json={"version": lead["version"]})
    assert second.json() == first.json()
    assert len(client.get(BASE + "/admin/platform").json()["collections"]["customers"]) == 1


def test_operator_operational_fields_only(authorized):
    client, h = authorized
    _, booking = fixtures(client, h)
    employees = client.get(BASE + "/admin/platform").json()["collections"]["employees"]
    manager = next(u for u in employees if u["fields"]["role"] == "Менеджер")
    booking["fields"]["manager"] = manager["id"]
    booking = client.put(
        BASE + "/admin/crm/bookings/" + booking["id"], headers=h, json=booking
    ).json()
    assert (
        client.delete(
            BASE + "/admin/employees/" + manager["id"] + "?version=1", headers=h
        ).status_code
        == 200
    )
    oh = login(client, "operator")
    update = {**booking, "fields": {**booking["fields"], "notes": "Подать автомобиль в 9:00"}}
    r = client.put(BASE + "/admin/crm/bookings/" + booking["id"], headers=oh, json=update)
    assert r.status_code == 200
    update = r.json()
    update["fields"]["amount"] = "1"
    assert (
        client.put(
            BASE + "/admin/crm/bookings/" + booking["id"], headers=oh, json=update
        ).status_code
        == 403
    )
    assert (
        client.post(
            BASE + "/admin/crm/customers", headers=oh, json=item("x", "x", "Активный", {})
        ).status_code
        == 403
    )
    assert (
        client.post(
            BASE + "/admin/crm/bookings",
            headers=oh,
            json={**booking, "id": "new-booking", "slug": "new-booking"},
        ).status_code
        == 403
    )


def test_last_owner_and_disabling_account_revokes_login(client):
    h = login(client, "super_admin")
    employees = client.get(BASE + "/admin/platform").json()["collections"]["employees"]
    owner = next(u for u in employees if u["fields"]["role"] == "Супер-администратор")
    assert (
        client.delete(
            BASE + "/admin/employees/" + owner["id"] + "?version=1", headers=h
        ).status_code
        == 409
    )
    manager = next(u for u in employees if u["fields"]["role"] == "Менеджер")
    assert (
        client.delete(
            BASE + "/admin/employees/" + manager["id"] + "?version=1", headers=h
        ).status_code
        == 200
    )
    assert (
        client.post(
            BASE + "/auth/login",
            headers=ORIGIN,
            json={"email": "manager@example.com", "password": PASSWORD},
        ).status_code
        == 401
    )


def test_ledger_same_reference_and_overpayment_rejected(authorized):
    client, h = authorized
    _, b = fixtures(client, h)
    p = item(
        "first",
        "Оплата",
        "Оплачен",
        {
            "booking": b["id"],
            "amount": "1000",
            "currency": "USD",
            "date": "2030-05-01",
            "method": "Перевод",
            "reference": "unique-bank",
        },
    )
    create(client, h, "payments", p)
    assert (
        client.get(BASE + "/admin/platform").json()["collections"]["bookings"][0]["fields"][
            "paymentStatus"
        ]
        == "Оплачен"
    )
    p.update(id="second", slug="second")
    p["fields"].update(amount="1", reference="unique-bank2")
    assert client.post(BASE + "/admin/crm/payments", headers=h, json=p).status_code == 422
    p.update(status="Ожидается")
    p["fields"]["reference"] = "unique-bank"
    assert client.post(BASE + "/admin/crm/payments", headers=h, json=p).status_code == 409


def test_media_reference_content_save_and_missing_image(authorized):
    client, h = authorized
    tour = client.get(BASE + "/public/tours").json()[0]
    tour["image"] = "/api/media/" + str(uuid4())
    path = BASE + "/admin/content/tours/" + tour["id"]
    assert client.put(path, headers=h, json=tour).status_code == 422
    image = io.BytesIO()
    Image.new("RGB", (40, 40), "red").save(image, "PNG")
    uploaded = client.post(BASE + "/admin/media", headers=h, content=image.getvalue()).json()
    tour["image"] = uploaded["url"]
    assert client.put(path, headers=h, json=tour).status_code == 200
    assert client.get(BASE + "/public/tours/" + tour["slug"]).json()["image"] == uploaded["url"]


def test_unpublished_content_hidden_from_manager(authorized):
    client, h = authorized
    tour = client.get(BASE + "/public/tours").json()[-1]
    tour.update(id="private-tour", slug="private-tour", status="Черновик")
    assert client.post(BASE + "/admin/content/tours", headers=h, json=tour).status_code == 201
    login(client, "manager")
    assert all(
        row["status"] == "Опубликован"
        for row in client.get(BASE + "/admin/platform").json()["collections"]["tours"]
    )


def test_concurrent_public_submissions_create_one_lead(client):
    from concurrent.futures import ThreadPoolExecutor

    from fastapi.testclient import TestClient

    from app.main import app

    payload = {
        "key": str(uuid4()),
        "name": "Повторная отправка",
        "consent": True,
        "fields": {"country": "KG", "email": "retry@example.com", "people": "2"},
    }

    def submit(_):
        with TestClient(app) as other:
            return other.post(BASE + "/public/leads", headers=ORIGIN, json=payload)

    with ThreadPoolExecutor(max_workers=2) as pool:
        responses = list(pool.map(submit, range(2)))
    assert [r.status_code for r in responses] == [201, 201]
    assert responses[0].json() == responses[1].json()
    with SessionLocal() as db:
        assert len(db.scalars(select(CRMEntry).where(CRMEntry.entity == "leads")).all()) == 1


def test_concurrent_payments_cannot_overpay(authorized):
    from concurrent.futures import ThreadPoolExecutor

    from fastapi.testclient import TestClient

    from app.main import app

    client, h = authorized
    _, booking = fixtures(client, h)
    cookie = client.cookies.get("zilal_session")

    def submit(n):
        p = item(
            "concurrent-" + str(n),
            "Оплата",
            "Оплачен",
            {
                "booking": booking["id"],
                "amount": "600",
                "currency": "USD",
                "date": "2030-05-01",
                "method": "Перевод",
                "reference": "concurrent-bank-" + str(n),
            },
        )
        with TestClient(app) as other:
            other.cookies.set("zilal_session", cookie)
            return other.post(BASE + "/admin/crm/payments", headers=h, json=p).status_code

    with ThreadPoolExecutor(max_workers=2) as pool:
        statuses = list(pool.map(submit, range(2)))
    assert sorted(statuses) == [201, 422]
    payments = client.get(BASE + "/admin/platform").json()["collections"]["payments"]
    assert len(payments) == 1
    assert payments[0]["fields"]["amount"] == "600"


def test_media_delete_rejects_in_use_and_removes_unused(authorized):
    client, h = authorized
    body = io.BytesIO()
    Image.new("RGB", (32, 32), "blue").save(body, "PNG")
    m = client.post(BASE + "/admin/media", headers=h, content=body.getvalue()).json()
    tour = client.get(BASE + "/public/tours").json()[0]
    tour["image"] = m["url"]
    assert (
        client.put(BASE + "/admin/content/tours/" + tour["id"], headers=h, json=tour).status_code
        == 200
    )
    assert client.delete(BASE + "/admin/media/" + m["id"], headers=h).status_code == 409
    unused = client.post(BASE + "/admin/media", headers=h, content=body.getvalue()).json()
    assert client.delete(BASE + "/admin/media/" + unused["id"], headers=h).status_code == 200
    assert client.get(BASE + "/public/media/" + unused["id"]).status_code == 404


def test_production_media_requires_durable_storage(authorized, monkeypatch):
    from app.config import config

    client, h = authorized
    monkeypatch.setattr(config(), "app_env", "production")
    monkeypatch.setattr(config(), "media_persistent", False)
    body = io.BytesIO()
    Image.new("RGB", (32, 32), "blue").save(body, "PNG")
    assert client.post(BASE + "/admin/media", headers=h, content=body.getvalue()).status_code == 503
