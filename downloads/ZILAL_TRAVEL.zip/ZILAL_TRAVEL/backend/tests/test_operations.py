import zipfile
from datetime import timedelta
from pathlib import Path
from uuid import uuid4

import pytest
from sqlalchemy import select
from test_workflow import BASE, ORIGIN, fixtures, login

from app.config import config
from app.database import SessionLocal
from app.mail import deliver
from app.maintenance import cleanup, create_backup, verify_backup
from app.models import Content, MailMessage, PaymentLink, Session, Translation, User, now
from app.translation_seed import import_translations

EN = Path(__file__).parents[2] / "frontend/data/content/examples-en.json"


def test_english_seed_is_idempotent_and_publication_is_independent(client, authorized):
    with SessionLocal() as db:
        preview = import_translations(db, EN)
        assert preview["created"] == 19
        assert db.scalar(select(Translation).where(Translation.locale == "en")) is None
        assert import_translations(db, EN, True)["created"] == 19
        assert import_translations(db, EN, True)["created"] == 0
    ru = client.get(BASE + "/public/platform").json()
    en = client.get(BASE + "/public/platform?locale=en").json()
    assert len(en["collections"]["tours"]) == len(ru["collections"]["tours"]) == 4
    assert en["collections"]["tours"][0]["title"] != ru["collections"]["tours"][0]["title"]
    assert (
        en["collections"]["tours"][0]["fields"]["amount"]
        == ru["collections"]["tours"][0]["fields"]["amount"]
    )
    assert (
        en["collections"]["reviews"][0]["fields"]["quote"]
        != ru["collections"]["reviews"][0]["fields"]["quote"]
    )
    with SessionLocal() as db:
        row = db.scalar(select(Content).where(Content.entity == "tours"))
        slug = row.slug
        next(t for t in row.translations if t.locale == "en").published = False
        db.commit()
    assert client.get(BASE + f"/public/tours/{slug}?locale=en").status_code == 404
    assert client.get(BASE + f"/public/tours/{slug}").status_code == 200
    assert len(client.get(BASE + "/public/platform?locale=en").json()["collections"]["tours"]) == 3
    assert client.get(BASE + "/public/platform?locale=xx").status_code == 422


def test_english_home_version_and_access(authorized):
    client, h = authorized
    data = {"heroTitle": "A journey", "heroDescription": "Your own pace", "version": 0}
    url = BASE + "/admin/site-translation/en"
    assert client.put(url, json=data, headers=ORIGIN).status_code == 403
    assert client.put(url, json=data, headers=h).status_code == 200
    assert client.put(url, json=data, headers=h).status_code == 409
    assert (
        client.get(BASE + "/public/platform?locale=en").json()["settings"]["heroTitle"]
        == "A journey"
    )
    login(client, "manager")
    assert client.get(url).status_code == 403
    assert client.get(BASE + "/admin/operations").status_code == 403


def test_enquiry_outbox_is_atomic_idempotent_and_english(client, monkeypatch):
    monkeypatch.setattr(config(), "mail_enabled", True)
    monkeypatch.setattr(config(), "notification_email", "team@example.com")
    data = {
        "key": str(uuid4()),
        "locale": "en",
        "name": "Traveller",
        "consent": True,
        "fields": {"email": "traveller@example.com", "country": "UK", "people": "2"},
    }
    first = client.post(BASE + "/public/leads", json=data, headers=ORIGIN)
    assert first.status_code == 201
    assert client.post(BASE + "/public/leads", json=data, headers=ORIGIN).json() == first.json()
    with SessionLocal() as db:
        rows = db.scalars(select(MailMessage)).all()
        assert len(rows) == 2
        assert next(r for r in rows if r.kind == "receipt").locale == "en"
    messages = []
    monkeypatch.setattr("app.mail.send_message", messages.append)
    assert deliver()["sent"] == 2
    assert (
        "not a confirmed booking"
        in next(m for m in messages if m["To"] == "traveller@example.com").get_content()
    )
    assert deliver()["sent"] == 0
    with SessionLocal() as db:
        assert all(
            r.status == "sent" and r.recipient == "" for r in db.scalars(select(MailMessage))
        )


def test_mail_failure_retries_without_exposing_smtp_secrets(monkeypatch):
    monkeypatch.setattr(config(), "mail_enabled", True)
    with SessionLocal() as db:
        db.add(
            MailMessage(
                key="retry",
                recipient="test@example.com",
                kind="receipt",
                locale="ru",
                reference="ZT-TEST",
            )
        )
        db.commit()

    def fail(_):
        raise OSError("secret-password or connection string must not be saved")

    monkeypatch.setattr("app.mail.send_message", fail)
    assert deliver()["failed"] == 1
    with SessionLocal() as db:
        row = db.scalar(select(MailMessage))
        assert row.last_error == "OSError" and row.status == "pending" and row.attempts == 1
        assert row.next_attempt > now()
    assert deliver()["failed"] == 0


def test_cleanup_only_expired_sessions():
    with SessionLocal() as db:
        user = db.scalar(select(User))
        db.add_all(
            [
                Session(
                    token_hash="old",
                    user_id=user.id,
                    csrf="csrf",
                    expires_at=now() - timedelta(hours=1),
                ),
                Session(
                    token_hash="active",
                    user_id=user.id,
                    csrf="csrf",
                    expires_at=now() + timedelta(hours=1),
                ),
            ]
        )
        db.commit()
        assert cleanup(db)["sessions"] == 1
        db.commit()
        assert db.get(Session, "active") and not db.get(Session, "old")


def test_backup_keeps_verified_archive_and_does_not_prune_on_failure(tmp_path, monkeypatch):
    root, media = tmp_path / "backups", tmp_path / "media"
    media.mkdir()
    (media / "photo.webp").write_bytes(b"public image test")
    monkeypatch.setattr(config(), "backup_root", str(root))
    monkeypatch.setattr(config(), "media_root", str(media))
    monkeypatch.setattr(config(), "backup_keep", 1)
    monkeypatch.setattr(
        "app.maintenance.dump_database", lambda p: p.write_bytes(b"private database test")
    )
    with SessionLocal() as db:
        first = create_backup(db)
        db.commit()
        second = create_backup(db)
        db.commit()
        assert not (root / first).exists() and (root / second).exists()
        assert "media/photo.webp" in verify_backup(root / second)["files"]

        def fail(_):
            raise RuntimeError("dump failed")

        monkeypatch.setattr("app.maintenance.dump_database", fail)
        with pytest.raises(RuntimeError):
            create_backup(db)
        db.rollback()
        assert (root / second).exists()
    damaged = tmp_path / "damaged.zip"
    with zipfile.ZipFile(root / second) as source, zipfile.ZipFile(damaged, "w") as output:
        for name in source.namelist():
            output.writestr(name, b"damaged" if name == "database.dump" else source.read(name))
    with pytest.raises(RuntimeError, match="checksum"):
        verify_backup(damaged)


def test_manual_payment_link_is_private_expiring_and_cannot_confirm_payment(
    authorized, monkeypatch
):
    client, h = authorized
    _, booking = fixtures(client, h)
    url = BASE + f"/admin/bookings/{booking['id']}/payment-link"
    assert client.post(url, headers=h).status_code == 503
    monkeypatch.setattr(config(), "payment_instructions", "Test bank instructions")
    result = client.post(url, headers=h)
    assert result.status_code == 200
    token = result.json()["url"].split("token=")[1]
    info = BASE + "/public/payment-info"
    assert client.post(info, json={"token": token}).status_code == 403
    details = client.post(info, json={"token": token}, headers=ORIGIN)
    assert details.status_code == 200
    assert details.json()["remaining"] == "1000.00" and not details.json()["paid"]
    assert set(details.json()) == {"reference", "remaining", "currency", "instructions", "paid"}
    with SessionLocal() as db:
        row = db.scalar(select(PaymentLink))
        assert row.token_hash != token
        row.expires_at = now() - timedelta(seconds=1)
        db.commit()
    assert client.post(info, json={"token": token}, headers=ORIGIN).status_code == 404
    login(client, "manager")
    assert client.post(url, headers=login(client, "manager")).status_code == 403


def test_payment_link_balance_tracks_ledger_and_changed_terms(authorized, monkeypatch):
    from test_workflow import create, item

    client, h = authorized
    monkeypatch.setattr(config(), "payment_instructions", "Test instructions")
    _, booking = fixtures(client, h)
    url = BASE + f"/admin/bookings/{booking['id']}/payment-link"
    token = client.post(url, headers=h).json()["url"].split("token=")[1]
    create(
        client,
        h,
        "payments",
        item(
            "payment-test",
            "Transfer",
            "Оплачен",
            {
                "booking": booking["id"],
                "amount": "400",
                "currency": "USD",
                "date": "2030-01-01",
                "method": "Перевод",
                "reference": "bank-ref",
            },
        ),
    )
    info = BASE + "/public/payment-info"
    assert client.post(info, json={"token": token}, headers=ORIGIN).json()["remaining"] == "600.00"
    with SessionLocal() as db:
        from app.models import CRMEntry

        row = db.get(CRMEntry, booking["id"])
        row.fields = {**row.fields, "amount": "1200"}
        db.commit()
    assert client.post(info, json={"token": token}, headers=ORIGIN).status_code == 409


def test_smtp_delivers_to_a_local_test_server_only(monkeypatch):
    import socketserver
    import threading

    from app.mail import message_for, send_message

    captured = []

    class SMTPHandler(socketserver.StreamRequestHandler):
        def handle(self):
            self.wfile.write(b"220 local test SMTP\r\n")
            while line := self.rfile.readline():
                command = line.split(b" ", 1)[0].strip().upper()
                if command in {b"EHLO", b"HELO", b"MAIL", b"RCPT", b"RSET"}:
                    self.wfile.write(b"250 OK\r\n")
                elif command == b"DATA":
                    self.wfile.write(b"354 Send data\r\n")
                    body = b""
                    while (chunk := self.rfile.readline()) != b".\r\n":
                        body += chunk
                    captured.append(body)
                    self.wfile.write(b"250 Accepted\r\n")
                elif command == b"QUIT":
                    self.wfile.write(b"221 Bye\r\n")
                    break

    cfg = config()
    for key, value in {
        "mail_enabled": True,
        "smtp_host": "127.0.0.1",
        "smtp_security": "local",
        "smtp_from": "sender@example.com",
    }.items():
        monkeypatch.setattr(cfg, key, value)
    with socketserver.TCPServer(("127.0.0.1", 0), SMTPHandler) as server:
        monkeypatch.setattr(cfg, "smtp_port", server.server_address[1])
        thread = threading.Thread(target=server.serve_forever, daemon=True)
        thread.start()
        try:
            row = MailMessage(
                id="local-test",
                recipient="local@example.com",
                kind="receipt",
                locale="en",
                reference="ZT-LOCAL-ONLY",
            )
            send_message(message_for(row))
        finally:
            server.shutdown()
            thread.join(timeout=2)
    assert len(captured) == 1 and b"ZT-LOCAL-ONLY" in captured[0]
    monkeypatch.setattr(cfg, "app_env", "production")
    with pytest.raises(RuntimeError, match="smtp_tls_required"):
        send_message(message_for(row))


def test_last_attempt_delivery_crash_is_visible_not_stuck_forever(monkeypatch):
    monkeypatch.setattr(config(), "mail_enabled", True)
    with SessionLocal() as db:
        db.add(
            MailMessage(
                key="uncertain",
                recipient="test@example.com",
                kind="receipt",
                locale="en",
                reference="ZT-UNCERTAIN",
                status="sending",
                attempts=5,
                next_attempt=now() - timedelta(minutes=1),
            )
        )
        db.commit()
    assert deliver()["sent"] == 0
    with SessionLocal() as db:
        row = db.scalar(select(MailMessage))
        assert row.status == "failed" and row.last_error == "delivery_uncertain"


def test_backups_cannot_be_saved_into_public_site_files(monkeypatch):
    project = Path(__file__).parents[2]
    monkeypatch.setattr(config(), "backup_root", str(project / "frontend/public/unsafe-backups"))
    with SessionLocal() as db, pytest.raises(RuntimeError, match="public site directory"):
        create_backup(db)
    assert not (project / "frontend/public/unsafe-backups").exists()


def test_example_configuration_accepts_empty_optional_smtp_fields():
    from app.config import Config

    cfg = Config(_env_file=Path(__file__).parents[1] / ".env.example")
    assert cfg.smtp_from is None and cfg.notification_email is None
    assert not cfg.mail_enabled
