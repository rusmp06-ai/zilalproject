"""Prevent duplicate bank transaction references, including concurrent submissions."""

from alembic import op

revision = "30b54ca00711"
down_revision = "22a6ff2f27c6"
branch_labels = None
depends_on = None


def upgrade():
    op.execute(
        "CREATE UNIQUE INDEX uq_payment_reference ON crm_entries ((fields->>'reference')) WHERE entity = 'payments'"
    )


def downgrade():
    op.drop_index("uq_payment_reference", table_name="crm_entries")
