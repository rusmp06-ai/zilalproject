"""Track disk and Supabase photo storage without moving existing files."""

import sqlalchemy as sa
from alembic import op

revision = "a413f6ea93bd"
down_revision = "703c6d63a6ff"
branch_labels = None
depends_on = None


def upgrade():
    op.add_column(
        "media", sa.Column("storage_driver", sa.String(20), nullable=False, server_default="local")
    )
    op.alter_column("media", "storage_driver", server_default=None)


def downgrade():
    op.drop_column("media", "storage_driver")
