from alembic import context
from sqlalchemy import text

from app.database import engine
from app.models import Base
from app.supabase_setup import secure_tables


def run():
    with engine.connect() as connection:
        context.configure(connection=connection, target_metadata=Base.metadata, compare_type=True)
        with context.begin_transaction():
            context.run_migrations()
            # Supabase exposes public tables via Data API by default. This app uses
            # its own backend/auth, so all application tables remain backend-only.
            roles = set(
                connection.scalars(
                    text("SELECT rolname FROM pg_roles WHERE rolname IN ('anon', 'authenticated')")
                )
            )
            if roles == {"anon", "authenticated"}:
                secure_tables(connection)


run()
