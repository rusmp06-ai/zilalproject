import secrets
from datetime import timedelta

from fastapi import APIRouter, Depends, HTTPException, Query, Request
from pydantic import EmailStr, Field, ValidationError
from sqlalchemy import delete, select, text

from app.auth import digest, login_limit, origin, passwords, staff_writable
from app.crm import ROLE_LABELS, CRMInput, employee
from app.database import db_session
from app.models import AccessToken, Audit, Session, User, now
from app.schemas import Strict

router = APIRouter(prefix="/api/v1")


def admin(user):
    if user.role not in {"super_admin", "admin"}:
        raise HTTPException(403, "Сотрудниками управляет администратор")


class EmployeeFields(Strict):
    email: EmailStr
    phone: str = Field(default="", max_length=100)
    role: str


def save_employee(db, payload, actor, create=False):
    admin(actor)
    db.execute(text("SELECT pg_advisory_xact_lock(814097323)"))
    try:
        fields = EmployeeFields.model_validate(payload.fields)
    except ValidationError as exc:
        raise HTTPException(422, "Проверьте email, телефон и роль") from exc
    if len(payload.title) > 200:
        raise HTTPException(422, "Имя слишком длинное")
    roles = {v: k for k, v in ROLE_LABELS.items()}
    if fields.role not in roles or payload.status not in {"Активный", "Архив"}:
        raise HTTPException(422, "Некорректная роль или статус")
    role = roles[fields.role]
    row = db.scalar(select(User).where(User.id == payload.id).with_for_update())
    if actor.role != "super_admin" and (
        role in {"super_admin", "admin"} or row and row.role in {"super_admin", "admin"}
    ):
        raise HTTPException(403, "Администраторов назначает только владелец")
    if create:
        if row:
            raise HTTPException(409, "ID уже существует")
        row = User(
            id=payload.id,
            email=str(fields.email).lower(),
            name=payload.title,
            role=role,
            password_hash=passwords.hash(secrets.token_urlsafe(64)),
        )
        db.add(row)
    else:
        if not row:
            raise HTTPException(404)
        if row.version != payload.version:
            raise HTTPException(409, "Сотрудник изменён; обновите страницу")
        if row.id == actor.id and (role != row.role or payload.status != "Активный"):
            raise HTTPException(409, "Нельзя отключить или изменить собственную роль")
        if (
            row.role == "super_admin"
            and row.active
            and (role != "super_admin" or payload.status != "Активный")
        ):
            if (
                len(
                    db.scalars(select(User.id).where(User.role == "super_admin", User.active)).all()
                )
                < 2
            ):
                raise HTTPException(409, "Нельзя отключить последнего владельца")
        row.version += 1
        db.execute(delete(Session).where(Session.user_id == row.id))
        db.execute(delete(AccessToken).where(AccessToken.user_id == row.id))
    row.name, row.email, row.phone, row.role, row.active = (
        payload.title,
        str(fields.email).lower(),
        fields.phone,
        role,
        payload.status == "Активный",
    )
    db.add(
        Audit(
            user_id=actor.id,
            entity="employees",
            action="Создание" if create else "Изменение доступа",
            title=row.name,
        )
    )
    db.commit()
    return employee(row)


@router.post("/admin/employees", status_code=201)
def create(payload: CRMInput, auth=Depends(staff_writable), db=Depends(db_session)):
    return save_employee(db, payload, auth[1], True)


@router.put("/admin/employees/{id}")
def edit(id: str, payload: CRMInput, auth=Depends(staff_writable), db=Depends(db_session)):
    if payload.id != id:
        raise HTTPException(422)
    return save_employee(db, payload, auth[1])


@router.delete("/admin/employees/{id}")
def disable(
    id: str, version: int = Query(ge=1), auth=Depends(staff_writable), db=Depends(db_session)
):
    admin(auth[1])
    row = db.get(User, id)
    if not row:
        raise HTTPException(404)
    save_employee(db, CRMInput(**{**employee(row), "status": "Архив", "version": version}), auth[1])
    return {"ok": True}


@router.post("/admin/employees/{id}/invite")
def invite(id: str, auth=Depends(staff_writable), db=Depends(db_session)):
    admin(auth[1])
    user = db.scalar(select(User).where(User.id == id).with_for_update())
    if not user or not user.active:
        raise HTTPException(404, "Активный сотрудник не найден")
    if auth[1].role != "super_admin" and user.role in {"super_admin", "admin"}:
        raise HTTPException(403)
    token = secrets.token_urlsafe(48)
    db.execute(delete(AccessToken).where(AccessToken.user_id == id))
    db.add(AccessToken(token_hash=digest(token), user_id=id, expires_at=now() + timedelta(hours=1)))
    db.add(
        Audit(
            user_id=auth[1].id,
            entity="employees",
            action="Выдана ссылка для установки пароля",
            title=user.name,
        )
    )
    db.commit()
    from app.config import config

    return {"url": config().site_origin + "/reset-password#token=" + token, "expiresIn": 3600}


class ResetInput(Strict):
    token: str = Field(min_length=40, max_length=200)
    password: str = Field(min_length=12, max_length=200)
    model_config = {"extra": "forbid"}


@router.post("/auth/reset-password")
def reset(payload: ResetInput, request: Request, db=Depends(db_session)):
    origin(request)
    login_limit(db, request)
    existing = db.get(AccessToken, digest(payload.token))
    if not existing:
        raise HTTPException(400, "Ссылка истекла или уже использована. Обратитесь к администратору")
    # Account first, then token: same lock order as invitations and disabling access.
    user = db.scalar(select(User).where(User.id == existing.user_id).with_for_update())
    row = db.scalar(
        select(AccessToken)
        .where(AccessToken.token_hash == digest(payload.token))
        .with_for_update()
        .execution_options(populate_existing=True)
    )
    if not row or row.expires_at <= now() or not user or not user.active:
        raise HTTPException(400, "Ссылка истекла, использована или доступ отключён")
    user.password_hash = passwords.hash(payload.password)
    db.execute(delete(Session).where(Session.user_id == user.id))
    db.execute(delete(AccessToken).where(AccessToken.user_id == user.id))
    db.add(Audit(user_id=user.id, entity="employees", action="Пароль установлен", title=user.name))
    db.commit()
    return {"ok": True}


class ChangePassword(Strict):
    currentPassword: str = Field(min_length=1, max_length=200)
    password: str = Field(min_length=12, max_length=200)
    model_config = {"extra": "forbid"}


@router.post("/auth/change-password")
def change(
    payload: ChangePassword, request: Request, auth=Depends(staff_writable), db=Depends(db_session)
):
    from app.auth import verify

    login_limit(db, request)
    user = db.scalar(select(User).where(User.id == auth[1].id).with_for_update())
    if not verify(user, payload.currentPassword):
        raise HTTPException(401, "Текущий пароль неверен")
    user.password_hash = passwords.hash(payload.password)
    db.execute(delete(Session).where(Session.user_id == user.id))
    db.execute(delete(AccessToken).where(AccessToken.user_id == user.id))
    db.add(Audit(user_id=user.id, entity="employees", action="Пароль изменён", title=user.name))
    db.commit()
    return {"ok": True}
