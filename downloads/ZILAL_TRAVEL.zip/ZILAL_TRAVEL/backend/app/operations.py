from datetime import timedelta

from fastapi import APIRouter, Depends, HTTPException
from pydantic import Field
from sqlalchemy import func, select

from app.accounts import admin
from app.auth import current_session, staff_writable
from app.config import config
from app.database import db_session
from app.models import Audit, MailMessage, ServiceState, SiteTranslation, now
from app.schemas import Strict

router = APIRouter(prefix="/api/v1/admin")


@router.get("/operations")
def status(auth=Depends(current_session), db=Depends(db_session)):
    admin(auth[1])
    states = {
        row.key: {
            "checkedAt": row.checked_at.isoformat(),
            "successAt": row.success_at.isoformat() if row.success_at else None,
            "error": row.error,
        }
        for row in db.scalars(select(ServiceState))
    }
    worker = db.get(ServiceState, "worker")
    return {
        "services": states,
        "workerActive": bool(worker and worker.checked_at > now() - timedelta(minutes=2)),
        "mailEnabled": config().mail_enabled,
        "mailConfigured": bool(config().smtp_host and config().smtp_from),
        "mailCounts": dict(
            db.execute(select(MailMessage.status, func.count()).group_by(MailMessage.status)).all()
        ),
        "backupKeep": config().backup_keep,
        "paymentMode": "manual",
    }


class SiteEnglish(Strict):
    address: str = Field(default="", max_length=300)
    heroTitle: str = Field(min_length=1, max_length=300)
    heroDescription: str = Field(max_length=3000)
    version: int = Field(ge=0)


@router.get("/site-translation/en")
def english(auth=Depends(current_session), db=Depends(db_session)):
    admin(auth[1])
    row = db.get(SiteTranslation, "en")
    return {
        "heroTitle": row.hero_title if row else "",
        "heroDescription": row.hero_description if row else "",
        "address": row.address if row else "",
        "version": row.version if row else 0,
    }


@router.put("/site-translation/en")
def save_english(payload: SiteEnglish, auth=Depends(staff_writable), db=Depends(db_session)):
    admin(auth[1])
    # Also serializes first creation, when there is no row to lock yet.
    from sqlalchemy import text

    db.execute(text("SELECT pg_advisory_xact_lock(715804296)"))
    row = db.get(SiteTranslation, "en")
    if payload.version != (row.version if row else 0):
        raise HTTPException(409, "Перевод изменён; обновите страницу")
    if row is None:
        row = SiteTranslation(locale="en")
        db.add(row)
    row.address = payload.address
    row.hero_title = payload.heroTitle
    row.hero_description = payload.heroDescription
    row.version = payload.version + 1
    db.add(
        Audit(
            user_id=auth[1].id,
            action="Перевод главной en",
            entity="settings",
            title=payload.heroTitle,
        )
    )
    db.commit()
    return {
        "heroTitle": row.hero_title,
        "heroDescription": row.hero_description,
        "address": row.address,
        "version": row.version,
    }
