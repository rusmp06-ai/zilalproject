"""Private, atomic PostgreSQL + media backups and scheduled cleanup."""

import hashlib
import json
import os
import subprocess
import tempfile
import zipfile
from datetime import timedelta
from pathlib import Path
from uuid import uuid4

from fastapi import HTTPException
from sqlalchemy import delete, select, text
from sqlalchemy.engine import make_url

from app.config import config
from app.database import SessionLocal
from app.models import (
    AccessToken,
    LoginLimit,
    MailMessage,
    Media,
    PaymentLink,
    ServiceState,
    Session,
    now,
)

# Media writers take a shared transaction lock; backup takes the exclusive form.
MEDIA_LOCK = 715804294


def cleanup(db):
    counts = {}
    for model, field in (
        (PaymentLink, PaymentLink.expires_at),
        (Session, Session.expires_at),
        (AccessToken, AccessToken.expires_at),
        (LoginLimit, LoginLimit.until),
    ):
        counts[model.__tablename__] = db.execute(delete(model).where(field <= now())).rowcount
    counts["old_mail"] = db.execute(
        delete(MailMessage).where(
            MailMessage.status.in_(["sent", "failed"]),
            MailMessage.next_attempt < now() - timedelta(days=30),
        )
    ).rowcount
    return counts


def dump_database(target):
    cfg = config()
    url = make_url(cfg.database_url)
    if cfg.backup_driver == "docker":
        if url.host not in {"localhost", "127.0.0.1"}:
            raise RuntimeError("Docker backup supports only the local Compose database")
        command = [
            "docker",
            "compose",
            "exec",
            "-T",
            cfg.backup_docker_service,
            "pg_dump",
            "--format=custom",
            "--no-owner",
            "--no-acl",
            "--username",
            url.username,
            url.database,
        ]
        environment = dict(os.environ)
        cwd = Path(__file__).resolve().parents[2]
    elif cfg.backup_driver == "pg_dump":
        command = [cfg.pg_dump_path, "--format=custom", "--no-owner", "--no-acl", "--schema=public"]
        environment = dict(
            os.environ,
            PGHOST=url.host or "localhost",
            PGPORT=str(url.port or 5432),
            PGUSER=url.username or "",
            PGPASSWORD=url.password or "",
            PGDATABASE=url.database or "",
        )
        for key in ("sslmode", "sslrootcert", "sslcert", "sslkey"):
            if key in url.query:
                environment["PG" + key.upper()] = str(url.query[key])
        cwd = None
    else:
        raise RuntimeError("Unknown backup driver")
    with target.open("wb") as file:
        # stderr may contain connection details: don't display or store it.
        result = subprocess.run(
            command, env=environment, cwd=cwd, stdout=file, stderr=subprocess.PIPE, timeout=600
        )
    if result.returncode or target.stat().st_size < 20:
        raise RuntimeError("pg_dump_failed")


def create_backup(db):
    cfg = config()
    root = Path(cfg.backup_root).resolve()
    media = Path(cfg.media_root).resolve()
    project = Path(__file__).resolve().parents[2]
    for public in (project / "frontend/public", project / "images"):
        if root == public.resolve() or public.resolve() in root.parents:
            raise RuntimeError("Backup storage cannot be a public site directory")
    if root == media or media in root.parents or root in media.parents:
        raise RuntimeError("Backup storage must be separate from public media")
    root.mkdir(parents=True, exist_ok=True, mode=0o700)
    os.chmod(root, 0o700)
    db.execute(text("SELECT pg_advisory_xact_lock(:key)"), {"key": MEDIA_LOCK})
    name = "zilal-" + now().strftime("%Y%m%dT%H%M%S") + "-" + uuid4().hex[:8] + ".zip"
    with tempfile.TemporaryDirectory(dir=root) as temp:
        work = Path(temp)
        dump_database(work / "database.dump")
        paths = [(work / "database.dump", "database.dump")]
        if media.exists():
            for file in sorted(media.rglob("*")):
                if file.is_symlink():
                    raise RuntimeError("Media symlinks are not supported")
                if file.is_file():
                    paths.append((file, "media/" + file.relative_to(media).as_posix()))
        # Include private cloud photos; the dump alone cannot restore Storage objects.
        from app.media_storage import read_media

        remote = list(db.scalars(select(Media).where(Media.storage_driver == "supabase")))
        for row in remote:
            file = work / row.name
            file.write_bytes(read_media(row.name, row.storage_driver))
            paths.append((file, "media/" + row.name))
        manifest = {"version": 1, "createdAt": now().isoformat(), "files": {}}
        pending = work / name
        with zipfile.ZipFile(pending, "w", zipfile.ZIP_DEFLATED) as archive:
            for file, dest in paths:
                sha = hashlib.sha256()
                with file.open("rb") as source, archive.open(dest, "w") as output:
                    while chunk := source.read(1024 * 1024):
                        sha.update(chunk)
                        output.write(chunk)
                manifest["files"][dest] = sha.hexdigest()
            archive.writestr("manifest.json", json.dumps(manifest, ensure_ascii=False))
        verify_backup(pending)
        os.chmod(pending, 0o600)
        os.replace(pending, root / name)
    # Retention happens only after a successful, verified replacement.
    backups = sorted(root.glob("zilal-*.zip"), key=lambda p: p.stat().st_mtime, reverse=True)
    for old in backups[cfg.backup_keep :]:
        old.unlink()
    return name


def verify_backup(path):
    with zipfile.ZipFile(path) as archive:
        manifest = json.loads(archive.read("manifest.json"))
        if manifest.get("version") != 1 or "database.dump" not in manifest.get("files", {}):
            raise RuntimeError("Invalid backup manifest")
        if set(archive.namelist()) != {"manifest.json", *manifest["files"]}:
            raise RuntimeError("Unexpected backup files")
        for name, expected in manifest["files"].items():
            parts = Path(name).parts
            if name != "database.dump" and (
                not name.startswith("media/") or ".." in parts or "\\" in name
            ):
                raise RuntimeError("Unsafe backup path")
            sha = hashlib.sha256()
            with archive.open(name) as source:
                while chunk := source.read(1024 * 1024):
                    sha.update(chunk)
            if sha.hexdigest() != expected:
                raise RuntimeError("Backup checksum mismatch")
    return manifest


def run_maintenance(force_backup=False):
    result = {}
    with SessionLocal() as db:
        if not db.scalar(text("SELECT pg_try_advisory_xact_lock(715804295)")):
            return {"busy": True}
        for key in ("cleanup", "backup"):
            state = db.get(ServiceState, key)
            if state is None:
                state = ServiceState(key=key)
                db.add(state)
                db.flush()
            due = state.success_at is None or state.success_at < now() - timedelta(
                hours=1 if key == "cleanup" else 24
            )
            retry = not state.error or state.checked_at < now() - timedelta(minutes=15)
            if not ((due and retry) or key == "backup" and force_backup):
                continue
            state.checked_at = now()
            try:
                with db.begin_nested():
                    result[key] = cleanup(db) if key == "cleanup" else create_backup(db)
                state.success_at = now()
                state.error = ""
            except (
                HTTPException,
                OSError,
                RuntimeError,
                subprocess.SubprocessError,
                zipfile.BadZipFile,
            ) as exc:
                state.error = type(exc).__name__
                result[key] = {"error": state.error}
        worker = db.get(ServiceState, "worker")
        if worker is None:
            worker = ServiceState(key="worker")
            db.add(worker)
        worker.checked_at = now()
        worker.success_at = now()
        db.commit()
    return result
