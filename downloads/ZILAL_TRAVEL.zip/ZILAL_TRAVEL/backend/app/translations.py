from typing import Literal

from fastapi import APIRouter, Depends, HTTPException
from pydantic import Field
from sqlalchemy import delete, select

from app.auth import editor, writable
from app.content import TEXT_MAP, serialize
from app.database import db_session
from app.models import Audit, Content, TourLine, Translation
from app.schemas import ENTITIES, Strict

router = APIRouter(prefix="/api/v1")


class TranslationInput(Strict):
    title: str = Field(min_length=1, max_length=300)
    description: str = Field(default="", max_length=3000)
    fields: dict[str, str]
    version: int = Field(ge=1)
    published: bool = False


@router.get("/admin/translations/{entity}/{id}/{locale}")
def get(
    entity: str, id: str, locale: Literal["ru", "en"], auth=Depends(editor), db=Depends(db_session)
):
    row = db.get(Content, id)
    if not row or row.entity != entity or entity not in ENTITIES:
        raise HTTPException(404)
    return serialize(db, row, locale)


@router.put("/admin/translations/{entity}/{id}/{locale}")
def put(
    entity: str,
    id: str,
    locale: Literal["ru", "en"],
    payload: TranslationInput,
    auth=Depends(writable),
    db=Depends(db_session),
):
    row = db.scalar(select(Content).where(Content.id == id).with_for_update())
    if not row or row.entity != entity or entity not in ENTITIES:
        raise HTTPException(404)
    save_translation(db, row, locale, payload, auth[1].id)
    db.commit()
    return serialize(db, row, locale)


def save_translation(db, row, locale, payload, user_id):
    if row.version != payload.version:
        raise HTTPException(409, "Материал изменён; обновите перевод перед сохранением")
    from app.schemas import FIELD_MODELS

    allowed = {k: v for k, v in TEXT_MAP.items() if k in FIELD_MODELS[row.entity].model_fields}
    lines = ("itinerary", "included", "excluded", "faq") if row.entity == "tours" else ()
    if set(payload.fields) - set(allowed) - set(lines):
        raise HTTPException(422, "Перевод содержит нетекстовые поля")
    if any(
        len(v)
        > (
            100
            if k == "readingTime"
            else 300
            if k
            in {
                "label",
                "season",
                "startPoint",
                "seoTitle",
                "seoDescription",
                "alt",
                "author",
                "readingTime",
            }
            else 20000
        )
        for k, v in payload.fields.items()
    ):
        raise HTTPException(422, "Текст слишком длинный")
    tr = next((t for t in row.translations if t.locale == locale), None)
    if tr is None:
        tr = Translation(locale=locale, title=payload.title, description=payload.description)
        row.translations.append(tr)
    tr.title, tr.description, tr.published = (
        payload.title,
        payload.description,
        True if locale == "ru" else payload.published,
    )
    for key, attr in allowed.items():
        setattr(tr, attr, payload.fields.get(key, ""))
    if lines:
        db.execute(delete(TourLine).where(TourLine.tour_id == row.id, TourLine.locale == locale))
        for kind in lines:
            for position, line in enumerate(payload.fields.get(kind, "").splitlines()):
                if line.strip():
                    db.add(
                        TourLine(
                            tour_id=row.id,
                            locale=locale,
                            kind=kind,
                            position=position,
                            text=line.strip(),
                        )
                    )
    row.version += 1
    db.add(
        Audit(user_id=user_id, action="Перевод " + locale, entity=row.entity, title=payload.title)
    )
    db.flush()
