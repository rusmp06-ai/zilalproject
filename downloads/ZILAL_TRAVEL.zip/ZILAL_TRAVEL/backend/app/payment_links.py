"""Free manual-transfer instructions; a public visit can never mark a payment paid."""

import secrets
from datetime import timedelta
from decimal import Decimal
from typing import Literal

from fastapi import APIRouter, Depends, HTTPException, Request
from pydantic import Field
from sqlalchemy import delete, select

from app.accounts import admin
from app.auth import digest, origin, staff_writable
from app.config import config
from app.crm import paid_total
from app.database import db_session
from app.models import Audit, CRMEntry, PaymentLink, now
from app.schemas import Strict

router = APIRouter(prefix="/api/v1")


@router.post("/admin/bookings/{id}/payment-link")
def create(id: str, auth=Depends(staff_writable), db=Depends(db_session)):
    admin(auth[1])
    if not config().payment_instructions.strip():
        raise HTTPException(
            503, "Сначала задайте проверенные реквизиты PAYMENT_INSTRUCTIONS в настройках сервера"
        )
    row = db.scalar(
        select(CRMEntry).where(CRMEntry.id == id, CRMEntry.entity == "bookings").with_for_update()
    )
    if not row or row.status not in {"Подтверждено", "В поездке", "Завершено"}:
        raise HTTPException(422, "Нужна подтверждённая бронь")
    if Decimal(row.fields["amount"]) <= paid_total(db, id):
        raise HTTPException(409, "Бронь уже оплачена")
    token = secrets.token_urlsafe(48)
    reference = "ZT-P-" + secrets.token_hex(6).upper()
    db.execute(delete(PaymentLink).where(PaymentLink.booking_id == id))
    db.add(
        PaymentLink(
            token_hash=digest(token),
            booking_id=id,
            reference=reference,
            amount=row.fields["amount"],
            currency=row.fields["currency"],
            expires_at=now() + timedelta(days=3),
        )
    )
    db.add(
        Audit(
            user_id=auth[1].id,
            entity="bookings",
            action="Создана ссылка на реквизиты",
            title=row.title,
        )
    )
    db.commit()
    return {"url": config().site_origin + "/payment#token=" + token, "expiresIn": 259200}


class Lookup(Strict):
    token: str = Field(min_length=60, max_length=100)
    locale: Literal["ru", "en"] = "ru"


@router.post("/public/payment-info")
def lookup(payload: Lookup, request: Request, db=Depends(db_session)):
    origin(request)
    link = db.get(PaymentLink, digest(payload.token))
    if not link or link.expires_at <= now() or not config().payment_instructions.strip():
        raise HTTPException(404, "Ссылка недоступна или истекла")
    # Same parent lock as the ledger provides a consistent balance.
    row = db.scalar(select(CRMEntry).where(CRMEntry.id == link.booking_id).with_for_update())
    if not row or row.status == "Отменено":
        raise HTTPException(404, "Ссылка недоступна")
    if row.fields["currency"] != link.currency or Decimal(row.fields["amount"]) != Decimal(
        link.amount
    ):
        raise HTTPException(409, "Условия брони изменились; запросите новую ссылку")
    remaining = max(Decimal("0"), Decimal(link.amount) - paid_total(db, row.id))
    instructions = (
        config().payment_instructions_en
        if payload.locale == "en"
        else config().payment_instructions
    )
    return {
        "reference": link.reference,
        "remaining": str(remaining.quantize(Decimal("0.01"))),
        "currency": link.currency,
        "instructions": instructions or config().payment_instructions,
        "paid": remaining == 0,
    }
