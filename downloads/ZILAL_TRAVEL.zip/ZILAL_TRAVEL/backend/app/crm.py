import json
from datetime import date, timedelta
from decimal import Decimal
from typing import Literal
from uuid import uuid4

from fastapi import APIRouter, Depends, HTTPException, Query, Request
from pydantic import EmailStr, Field, ValidationError, field_validator, model_validator
from sqlalchemy import delete, select
from sqlalchemy.dialects.postgresql import insert

from app.auth import digest, origin, staff_writable
from app.database import db_session
from app.models import Audit, Content, CRMEntry, CRMLink, LeadReceipt, LoginLimit, User, now
from app.schemas import Strict

router = APIRouter(prefix="/api/v1")
CRM_ENTITIES = ("leads", "customers", "bookings", "partners", "payments")
ROLES = {
    "super_admin": (*CRM_ENTITIES, "employees"),
    "admin": (*CRM_ENTITIES, "employees"),
    "manager": ("leads", "customers", "bookings", "partners", "employees"),
    "operator": ("bookings", "partners", "customers", "employees"),
    "content_manager": (),
}
STATUSES = {
    "leads": (
        "Новый",
        "Связались",
        "Квалифицирован",
        "Предложение отправлено",
        "Переговоры",
        "Подтверждён",
        "Оплачен",
        "Путешествие завершено",
        "На паузе",
        "Потерян",
        "Отменён",
    ),
    "customers": ("Активный", "Архив"),
    "bookings": ("Черновик", "Подтверждено", "В поездке", "Завершено", "Отменено"),
    "partners": ("Активный", "Архив"),
    "payments": ("Ожидается", "Оплачен", "Возврат"),
}
ROLE_LABELS = {
    "super_admin": "Супер-администратор",
    "admin": "Администратор",
    "manager": "Менеджер",
    "content_manager": "Контент-менеджер",
    "operator": "Оператор",
}
Money = Decimal


class Contacts(Strict):
    email: str = Field(default="", max_length=254)
    phone: str = Field(default="", max_length=100)

    @field_validator("email")
    @classmethod
    def email_valid(cls, v):
        if v:
            from pydantic import TypeAdapter

            return str(TypeAdapter(EmailStr).validate_python(v)).lower()
        return v


class CustomerFields(Contacts):
    country: str = Field(default="", max_length=100)
    language: Literal["Русский", "English"] = "Русский"
    preferences: str = Field(default="", max_length=20000)
    communication: str = Field(default="", max_length=20000)


class LeadFields(Contacts):
    country: str = Field(default="", max_length=100)
    start: str = ""
    end: str = ""
    people: int = Field(ge=1, le=100)
    interests: str = Field(default="", max_length=1000)
    stay: str = Field(default="", max_length=300)
    budget: Decimal | None = Field(default=None, ge=0, max_digits=12, decimal_places=2)
    tour: str = Field(default="", max_length=100)
    manager: str = Field(default="", max_length=100)
    customer: str = Field(default="", max_length=100)
    communication: str = Field(default="", max_length=20000)

    @field_validator("budget", mode="before")
    @classmethod
    def blank_budget(cls, v):
        return None if v == "" else v

    @model_validator(mode="after")
    def dates(self):
        if bool(self.start) != bool(self.end):
            raise ValueError("Укажите обе даты")
        if self.start and date.fromisoformat(self.end) < date.fromisoformat(self.start):
            raise ValueError("Дата окончания раньше начала")
        return self


class BookingFields(Strict):
    customer: str = Field(min_length=1, max_length=100)
    tour: str = Field(default="", max_length=100)
    start: date
    people: int = Field(ge=1, le=100)
    amount: Decimal = Field(ge=0, max_digits=12, decimal_places=2)
    currency: Literal["USD", "KGS", "EUR"]
    paymentStatus: Literal["Не оплачен", "Частично", "Оплачен"] = "Не оплачен"
    manager: str = Field(default="", max_length=100)
    guide: str = Field(default="", max_length=100)
    partner: str = Field(default="", max_length=100)
    transport: str = Field(default="", max_length=300)
    notes: str = Field(default="", max_length=20000)


class PartnerFields(Contacts):
    type: Literal["Отель", "Водитель", "Гид", "Лошади", "Ресторан", "Кемп", "Другой"]
    contact: str = Field(default="", max_length=300)
    region: str = Field(default="", max_length=300)


class PaymentFields(Strict):
    booking: str = Field(min_length=1, max_length=100)
    amount: Decimal = Field(gt=0, max_digits=12, decimal_places=2)
    currency: Literal["USD", "KGS", "EUR"]
    date: date
    method: Literal["Перевод", "Карта", "Наличные"]
    reference: str = Field(min_length=1, max_length=300)


MODELS = {
    "leads": LeadFields,
    "customers": CustomerFields,
    "bookings": BookingFields,
    "partners": PartnerFields,
    "payments": PaymentFields,
}
LINKS = {
    "tour": "tours",
    "customer": "customers",
    "manager": "employees",
    "guide": "employees",
    "partner": "partners",
    "booking": "bookings",
}


class CRMInput(Strict):
    id: str = Field(pattern=r"^[a-zA-Z0-9][a-zA-Z0-9_-]{0,99}$")
    slug: str = Field(max_length=150)
    title: str = Field(min_length=1, max_length=300)
    description: str = Field(default="", max_length=3000)
    image: str = "/images/lake.svg"
    status: str = Field(max_length=50)
    fields: dict[str, str]
    version: int | None = Field(default=None, ge=1)

    @field_validator("id")
    @classmethod
    def reserved_id(cls, value):
        if value == "new":
            raise ValueError("Reserved id")
        return value


def permitted(user, entity, write=False):
    if entity not in ROLES[user.role] or (write and entity == "employees"):
        raise HTTPException(403, "Нет доступа к разделу")
    if write and user.role == "operator" and entity not in {"bookings", "partners"}:
        raise HTTPException(403, "Нет права изменять запись")
    if write and user.role == "manager" and entity == "partners":
        raise HTTPException(403, "Партнёрами управляет администратор или оператор")


def serialize(row):
    return dict(
        id=row.id,
        slug=row.id,
        title=row.title,
        description=row.description,
        image="/images/lake.svg",
        status=row.status,
        fields=row.fields,
        version=row.version,
    )


def employee(row, full=True):
    return dict(
        id=row.id,
        slug=row.id,
        title=row.name,
        description="",
        image="/images/lake.svg",
        status="Активный" if row.active else "Архив",
        version=row.version,
        fields={
            "role": ROLE_LABELS[row.role],
            "email": row.email if full else "",
            "phone": row.phone if full else "",
        },
    )


def extend_snapshot(db, data, user):
    for row in db.scalars(
        select(CRMEntry)
        .where(CRMEntry.entity.in_(ROLES[user.role]))
        .order_by(CRMEntry.created_at, CRMEntry.id)
    ):
        data["collections"][row.entity].append(serialize(row))
    if "employees" in ROLES[user.role]:
        data["collections"]["employees"] = [
            employee(u, user.role in {"super_admin", "admin"})
            for u in db.scalars(select(User).order_by(User.name))
        ]
    # Content managers and operational staff cannot read audit titles containing traveller details.
    if user.role not in {"super_admin", "admin"}:
        data["activity"] = [
            a
            for a in data["activity"]
            if a["entity"]
            in ("tours", "destinations", "experiences", "journal", "gallery", "reviews")
        ]
    return data


def paid_total(db, booking_id, exclude=None):
    result = Decimal("0")
    for p in db.scalars(select(CRMEntry).where(CRMEntry.entity == "payments")):
        if p.id != exclude and p.fields.get("booking") == booking_id:
            result += Decimal(p.fields["amount"]) * (
                1 if p.status == "Оплачен" else -1 if p.status == "Возврат" else 0
            )
    return result


def reconcile(db, booking):
    total = paid_total(db, booking.id)
    fields = dict(booking.fields)
    fields["paymentStatus"] = (
        "Не оплачен"
        if total <= 0
        else "Оплачен"
        if total >= Decimal(fields["amount"])
        else "Частично"
    )
    if fields != booking.fields:
        booking.fields = fields
        booking.version += 1


def save(db, entity, payload, user, create=False):
    permitted(user, entity, True)
    if entity not in MODELS or payload.status not in STATUSES[entity]:
        raise HTTPException(422, "Некорректный раздел или статус")
    try:
        validated = MODELS[entity].model_validate(payload.fields)
    except ValidationError as exc:
        raise HTTPException(
            422, "Проверьте поля: " + ", ".join(str(e["loc"][0]) for e in exc.errors())
        ) from exc
    fields = {k: "" if v is None else str(v) for k, v in validated.model_dump().items()}
    # Always lock the parent booking before a payment, serializing ledger changes.
    booking = None
    if entity == "payments":
        booking = db.scalar(
            select(CRMEntry)
            .where(CRMEntry.id == fields["booking"], CRMEntry.entity == "bookings")
            .with_for_update()
        )
        if not booking or booking.fields["currency"] != fields["currency"]:
            raise HTTPException(422, "Бронирование не найдено или валюта не совпадает")
    row = db.scalar(select(CRMEntry).where(CRMEntry.id == payload.id).with_for_update())
    if create:
        if row:
            raise HTTPException(409, "ID уже существует")
        row = CRMEntry(
            id=payload.id, entity=entity, title=payload.title, status=payload.status, fields=fields
        )
        db.add(row)
    else:
        if not row or row.entity != entity:
            raise HTTPException(404)
        if row.version != payload.version:
            raise HTTPException(409, "Запись изменена. Обновите страницу")
        if entity == "payments" and row.status != "Ожидается":
            raise HTTPException(
                409, "Проведённая операция неизменяема; возврат оформляется отдельной записью"
            )
        if entity == "payments" and row.fields["booking"] != fields["booking"]:
            raise HTTPException(422, "Нельзя перенести платёж в другое бронирование")
        if entity == "bookings":
            total = paid_total(db, row.id)
            history = any(
                p.fields.get("booking") == row.id and p.status in {"Оплачен", "Возврат"}
                for p in db.scalars(select(CRMEntry).where(CRMEntry.entity == "payments"))
            )
            if (history and fields["currency"] != row.fields["currency"]) or Decimal(
                fields["amount"]
            ) < total:
                raise HTTPException(
                    409, "Стоимость или валюту нельзя изменить при проведённых оплатах"
                )
            if user.role == "operator":
                protected = ("customer", "tour", "amount", "currency", "manager")
                if any(fields[k] != row.fields[k] for k in protected):
                    raise HTTPException(403, "Оператор изменяет только операционные детали поездки")
        row.version += 1
    previous_fields = dict(row.fields) if not create else {}
    if entity == "bookings" and user.role == "operator" and create:
        raise HTTPException(403, "Бронирование создаёт менеджер")
    if booking:
        total = paid_total(db, booking.id, row.id)
        delta = Decimal(fields["amount"]) * (
            1 if payload.status == "Оплачен" else -1 if payload.status == "Возврат" else 0
        )
        if total + delta < 0 or total + delta > Decimal(booking.fields["amount"]):
            raise HTTPException(
                422, "Оплата превышает стоимость или возврат превышает полученную сумму"
            )
        if db.scalar(
            select(CRMEntry.id).where(
                CRMEntry.entity == "payments",
                CRMEntry.id != row.id,
                CRMEntry.fields["reference"].as_string() == fields["reference"],
            )
        ):
            raise HTTPException(409, "Номер операции уже зарегистрирован")
    row.title, row.description, row.status, row.fields = (
        payload.title,
        payload.description,
        payload.status,
        fields,
    )
    db.flush()
    db.execute(delete(CRMLink).where(CRMLink.source_id == row.id))
    for key, target in LINKS.items():
        value = fields.get(key)
        if not value:
            continue
        model = User if target == "employees" else Content if target == "tours" else CRMEntry
        linked = db.scalar(select(model).where(model.id == value).with_for_update())
        if (
            not linked
            or (model == CRMEntry and linked.entity != target)
            or (model == Content and linked.entity != "tours")
        ):
            raise HTTPException(422, "Связанная запись не найдена: " + key)
        changed_reference = previous_fields.get(key) != value
        if model == User and not linked.active and changed_reference:
            raise HTTPException(422, "Сотрудник отключён")
        if (
            model == User
            and key == "manager"
            and changed_reference
            and linked.role not in {"super_admin", "admin", "manager"}
        ):
            raise HTTPException(422, "Ответственному сотруднику нужен доступ менеджера к CRM")
        db.add(
            CRMLink(
                source_id=row.id,
                field=key,
                **{
                    "user_id"
                    if model == User
                    else "content_id"
                    if model == Content
                    else "crm_id": value
                },
            )
        )
    db.flush()
    if entity == "bookings":
        reconcile(db, row)
    if booking:
        reconcile(db, booking)
    db.add(
        Audit(
            user_id=user.id,
            entity=entity,
            action="Создание" if create else "Редактирование",
            title=payload.title,
        )
    )
    db.flush()
    return row


@router.post("/admin/crm/{entity}", status_code=201)
def create(entity: str, payload: CRMInput, auth=Depends(staff_writable), db=Depends(db_session)):
    row = save(db, entity, payload, auth[1], True)
    db.commit()
    return serialize(row)


@router.put("/admin/crm/{entity}/{id}")
def edit(
    entity: str, id: str, payload: CRMInput, auth=Depends(staff_writable), db=Depends(db_session)
):
    if payload.id != id:
        raise HTTPException(422)
    row = save(db, entity, payload, auth[1])
    db.commit()
    return serialize(row)


@router.delete("/admin/crm/{entity}/{id}")
def remove(
    entity: str,
    id: str,
    version: int = Query(ge=1),
    auth=Depends(staff_writable),
    db=Depends(db_session),
):
    permitted(auth[1], entity, True)
    row = db.scalar(
        select(CRMEntry).where(CRMEntry.id == id, CRMEntry.entity == entity).with_for_update()
    )
    if not row:
        raise HTTPException(404)
    if version != row.version:
        raise HTTPException(409, "Запись изменена")
    if entity in {"payments", "bookings"}:
        raise HTTPException(
            409, "Финансовые и поездочные записи сохраняются для истории; используйте статус отмены"
        )
    db.add(Audit(user_id=auth[1].id, action="Удаление", entity=entity, title=row.title))
    db.delete(row)
    db.commit()
    return {"ok": True}


class PublicLead(Strict):
    locale: Literal["ru", "en"] = "ru"
    key: str = Field(pattern=r"^[a-f0-9-]{36}$")
    name: str = Field(min_length=1, max_length=100)
    notes: str = Field(default="", max_length=3000)
    consent: Literal[True]
    fields: LeadFields

    @model_validator(mode="after")
    def public_only(self):
        if self.fields.manager or self.fields.customer or self.fields.communication:
            raise ValueError("Внутренние поля недоступны")
        if not self.fields.email or not self.fields.country:
            raise ValueError("Укажите email и страну")
        if self.fields.start and date.fromisoformat(self.fields.start) < date.today():
            raise ValueError("Дата поездки уже прошла")
        return self


@router.post("/public/leads", status_code=201)
def submit_lead(payload: PublicLead, request: Request, db=Depends(db_session)):
    origin(request)
    key = digest(payload.key)
    fingerprint = digest(json.dumps(payload.model_dump(mode="json"), sort_keys=True))
    # An advisory lock protects retry receipts, including concurrent identical submissions.
    from sqlalchemy import text

    db.execute(text("SELECT pg_advisory_xact_lock(:key)"), {"key": int(key[:15], 16)})
    receipt = db.get(LeadReceipt, key)
    if receipt:
        if receipt.payload_hash != fingerprint:
            raise HTTPException(409, "Повторный запрос содержит другие данные")
        return {"reference": receipt.reference}
    limit_key = digest("lead:" + (request.client.host if request.client else "unknown"))
    db.execute(
        insert(LoginLimit)
        .values(key=limit_key, count=0, until=now() + timedelta(hours=1))
        .on_conflict_do_nothing()
    )
    limit = db.scalar(select(LoginLimit).where(LoginLimit.key == limit_key).with_for_update())
    if limit.until <= now():
        limit.count, limit.until = 0, now() + timedelta(hours=1)
    if limit.count >= 30:
        raise HTTPException(429, "Слишком много заявок. Попробуйте позже")
    limit.count += 1
    fields = {k: "" if v is None else str(v) for k, v in payload.fields.model_dump().items()}
    if fields["tour"]:
        tour = db.scalar(
            select(Content)
            .where(
                Content.id == fields["tour"],
                Content.entity == "tours",
                Content.status == "Опубликован",
            )
            .with_for_update()
        )
        if not tour:
            raise HTTPException(422, "Выбранный тур недоступен")
    managers = db.scalars(
        select(User).where(User.active, User.role == "manager").order_by(User.id)
    ).all()
    if managers:
        loads = {m.id: 0 for m in managers}
        for lead in db.scalars(select(CRMEntry).where(CRMEntry.entity == "leads")):
            if (
                lead.status not in {"Потерян", "Отменён", "Путешествие завершено"}
                and lead.fields.get("manager") in loads
            ):
                loads[lead.fields["manager"]] += 1
        manager = min(managers, key=lambda m: (loads[m.id], m.id))
        manager = db.scalar(
            select(User)
            .where(User.id == manager.id)
            .with_for_update()
            .execution_options(populate_existing=True)
        )
        if manager.active and manager.role == "manager":
            fields["manager"] = manager.id
    row = CRMEntry(
        id="lead-" + str(uuid4()),
        entity="leads",
        title=payload.name,
        description=payload.notes,
        status="Новый",
        fields=fields,
    )
    db.add(row)
    db.flush()
    if fields["tour"]:
        db.add(CRMLink(source_id=row.id, field="tour", content_id=fields["tour"]))
    if fields["manager"]:
        db.add(CRMLink(source_id=row.id, field="manager", user_id=fields["manager"]))
    reference = "ZT-" + secrets_reference()
    db.add(LeadReceipt(key=key, payload_hash=fingerprint, lead_id=row.id, reference=reference))
    db.add(Audit(entity="leads", action="Заявка с сайта", title=payload.name))
    from app.mail import enqueue_lead

    enqueue_lead(db, reference, str(payload.fields.email), payload.locale)
    db.commit()
    return {"reference": reference}


def secrets_reference():
    import secrets

    return secrets.token_hex(8).upper()


class ConvertInput(Strict):
    version: int = Field(ge=1)


@router.post("/admin/leads/{id}/convert")
def convert(id: str, payload: ConvertInput, auth=Depends(staff_writable), db=Depends(db_session)):
    permitted(auth[1], "leads", True)
    row = db.scalar(
        select(CRMEntry).where(CRMEntry.id == id, CRMEntry.entity == "leads").with_for_update()
    )
    if not row:
        raise HTTPException(404)
    if row.fields.get("customer"):
        customer = db.get(CRMEntry, row.fields["customer"])
        return {"lead": serialize(row), "customer": serialize(customer)}
    if row.version != payload.version:
        raise HTTPException(409, "Заявка изменена; обновите страницу")
    from sqlalchemy import text

    db.execute(
        text("SELECT pg_advisory_xact_lock(:key)"),
        {"key": int(digest("customer:" + row.fields.get("email", id))[:15], 16)},
    )
    customer = (
        db.scalar(
            select(CRMEntry).where(
                CRMEntry.entity == "customers",
                CRMEntry.fields["email"].as_string() == row.fields.get("email"),
            )
        )
        if row.fields.get("email")
        else None
    )
    if not customer:
        customer = CRMEntry(
            id="customer-" + str(uuid4()),
            entity="customers",
            title=row.title,
            description=row.description,
            status="Активный",
            fields={
                "country": row.fields.get("country", ""),
                "email": row.fields.get("email", ""),
                "phone": row.fields.get("phone", ""),
                "language": "Русский",
                "preferences": row.fields.get("interests", ""),
                "communication": row.fields.get("communication", ""),
            },
        )
        db.add(customer)
        db.flush()
    row.fields = {**row.fields, "customer": customer.id}
    row.version += 1
    db.add(CRMLink(source_id=row.id, field="customer", crm_id=customer.id))
    db.add(
        Audit(user_id=auth[1].id, entity="leads", action="Создан / связан клиент", title=row.title)
    )
    db.commit()
    return {"lead": serialize(row), "customer": serialize(customer)}
