import secrets
from datetime import timedelta
from typing import Literal

from fastapi import Depends, FastAPI, HTTPException, Query, Request, Response
from fastapi.responses import JSONResponse
from sqlalchemy import select, text
from sqlalchemy.exc import IntegrityError

from app.accounts import router as accounts_router
from app.auth import (
    current_session,
    digest,
    login_limit,
    origin,
    staff_writable,
    verify,
    writable,
)
from app.config import config
from app.content import save_item, serialize, settings_out, snapshot, update_settings
from app.crm import router as crm_router
from app.database import db_session
from app.media import MAX_UPLOAD
from app.media import router as media_router
from app.models import Audit, Content, Session, User, now
from app.operations import router as operations_router
from app.payment_links import router as payment_links_router
from app.schemas import ENTITIES, ItemInput, Login, SettingsInput
from app.translations import router as translations_router

if config().app_env == "production" and not config().site_origin.startswith("https://"):
    raise RuntimeError("Production requires HTTPS SITE_ORIGIN")
app = FastAPI(
    title="ZILAL TRAVEL API",
    version="0.1.0",
    docs_url=None if config().app_env == "production" else "/docs",
    redoc_url=None,
)


app.include_router(crm_router)
app.include_router(accounts_router)
app.include_router(media_router)
app.include_router(translations_router)
app.include_router(operations_router)
app.include_router(payment_links_router)


@app.middleware("http")
async def bounds(request, call_next):
    try:
        length = int(request.headers.get("content-length", "0"))
    except ValueError:
        return JSONResponse({"detail": "Некорректный размер запроса"}, status_code=400)
    max_body = MAX_UPLOAD if request.url.path == "/api/v1/admin/media" else 262144
    if length > max_body:
        return JSONResponse({"detail": "Запрос слишком большой"}, status_code=413)
    if request.method in {"POST", "PUT", "PATCH"}:
        body = bytearray()
        async for chunk in request.stream():
            body.extend(chunk)
            if len(body) > max_body:
                return JSONResponse({"detail": "Запрос слишком большой"}, status_code=413)
        request._body = bytes(body)
    response = await call_next(request)
    response.headers["Cache-Control"] = "no-store"
    response.headers["X-Content-Type-Options"] = "nosniff"
    return response


@app.exception_handler(IntegrityError)
async def integrity_handler(request, exc):
    return JSONResponse(
        {"detail": "Адрес уже занят или запись связана с другими данными"}, status_code=409
    )


@app.get("/health")
def health(db=Depends(db_session)):
    db.execute(text("SELECT 1"))
    return {"status": "ok"}


@app.post("/api/v1/auth/login")
def login(payload: Login, request: Request, response: Response, db=Depends(db_session)):
    origin(request)
    login_limit(db, request)
    user = db.scalar(select(User).where(User.email == str(payload.email).lower()))
    if not verify(user, payload.password):
        raise HTTPException(401, "Неверный email или пароль")
    token, csrf = secrets.token_urlsafe(48), secrets.token_urlsafe(32)
    db.add(
        Session(
            token_hash=digest(token),
            user_id=user.id,
            csrf=csrf,
            expires_at=now() + timedelta(hours=config().session_hours),
        )
    )
    db.commit()
    response.set_cookie(
        "zilal_session",
        token,
        httponly=True,
        secure=config().app_env == "production",
        samesite="lax",
        max_age=config().session_hours * 3600,
        path="/",
    )
    return {"user": {"id": user.id, "name": user.name, "role": user.role}, "csrf": csrf}


@app.get("/api/v1/auth/me")
def me(auth=Depends(current_session)):
    session, user = auth
    return {"user": {"id": user.id, "name": user.name, "role": user.role}, "csrf": session.csrf}


@app.post("/api/v1/auth/logout")
def logout(response: Response, auth=Depends(staff_writable), db=Depends(db_session)):
    db.delete(auth[0])
    db.commit()
    response.delete_cookie("zilal_session", path="/")
    return {"ok": True}


@app.get("/api/v1/public/platform")
def public_platform(locale: Literal["ru", "en"] = "ru", db=Depends(db_session)):
    return snapshot(db, locale=locale)


@app.get("/api/v1/admin/platform")
def admin_platform(auth=Depends(current_session), db=Depends(db_session)):
    from app.crm import extend_snapshot

    return extend_snapshot(
        db, snapshot(db, admin=auth[1].role in {"super_admin", "admin", "content_manager"}), auth[1]
    )


@app.get("/api/v1/public/{entity}")
def public_list(entity: str, locale: Literal["ru", "en"] = "ru", db=Depends(db_session)):
    if entity not in ENTITIES:
        raise HTTPException(404)
    return snapshot(db, locale=locale)["collections"][entity]


@app.get("/api/v1/public/{entity}/{slug}")
def public_detail(
    entity: str, slug: str, locale: Literal["ru", "en"] = "ru", db=Depends(db_session)
):
    row = db.scalar(
        select(Content).where(
            Content.entity == entity, Content.slug == slug, Content.status == "Опубликован"
        )
    )
    if not row or entity not in ENTITIES:
        raise HTTPException(404, "Материал не найден")
    tr = next((t for t in row.translations if t.locale == locale), None)
    if not tr or not tr.published:
        raise HTTPException(404, "Перевод ещё не опубликован")
    return serialize(db, row, locale)


@app.post("/api/v1/admin/content/{entity}", status_code=201)
def create(entity: str, payload: ItemInput, auth=Depends(writable), db=Depends(db_session)):
    row = save_item(db, entity, payload, auth[1].id, create=True)
    db.commit()
    return serialize(db, row)


@app.put("/api/v1/admin/content/{entity}/{id}")
def edit(entity: str, id: str, payload: ItemInput, auth=Depends(writable), db=Depends(db_session)):
    if id != payload.id:
        raise HTTPException(422, "ID не совпадает")
    row = save_item(db, entity, payload, auth[1].id)
    db.commit()
    return serialize(db, row)


@app.delete("/api/v1/admin/content/{entity}/{id}")
def remove(
    entity: str, id: str, version: int = Query(ge=1), auth=Depends(writable), db=Depends(db_session)
):
    row = db.scalar(
        select(Content).where(Content.id == id, Content.entity == entity).with_for_update()
    )
    if not row or entity not in ENTITIES:
        raise HTTPException(404)
    if row.version != version:
        raise HTTPException(409, "Запись изменена. Обновите страницу")
    title = serialize(db, row)["title"]
    db.delete(row)
    db.add(Audit(user_id=auth[1].id, action="Удаление", entity=entity, title=title))
    db.commit()
    return {"ok": True}


@app.put("/api/v1/admin/settings")
def settings(payload: SettingsInput, auth=Depends(writable), db=Depends(db_session)):
    if auth[1].role not in {"super_admin", "admin"}:
        raise HTTPException(403, "Настройки доступны администратору")
    row = update_settings(db, payload, auth[1].id)
    db.commit()
    return settings_out(row)
