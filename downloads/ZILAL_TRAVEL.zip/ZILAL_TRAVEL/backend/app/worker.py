"""Start separately: python -m app.worker. No external paid scheduler needed."""

import argparse
import json
import signal
import threading

from app.mail import deliver
from app.maintenance import run_maintenance


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--once", action="store_true")
    parser.add_argument("--backup-now", action="store_true")
    args = parser.parse_args()
    stopped = threading.Event()
    signal.signal(signal.SIGTERM, lambda *_: stopped.set())
    signal.signal(signal.SIGINT, lambda *_: stopped.set())
    while not stopped.is_set():
        result = run_maintenance(force_backup=args.backup_now)
        result["mail"] = deliver()
        if (
            args.once
            or len(result) > 1
            or result["mail"].get("sent")
            or result["mail"].get("failed")
        ):
            print(json.dumps(result, ensure_ascii=False), flush=True)
        if args.once:
            break
        args.backup_now = False
        stopped.wait(30)


if __name__ == "__main__":
    main()
