"""Transactional enquiry notifications. Delivery runs separately from HTTP requests."""

import smtplib
import ssl
from datetime import timedelta
from email.message import EmailMessage
from email.utils import formatdate
from urllib.parse import urlsplit

from sqlalchemy import or_, select, update

from app.config import config
from app.database import SessionLocal
from app.models import MailMessage, now


def enqueue_lead(db, reference, recipient, locale):
    if not config().mail_enabled:
        return
    db.add(
        MailMessage(
            key="lead:" + reference,
            recipient=recipient,
            locale=locale,
            kind="receipt",
            reference=reference,
        )
    )
    if config().notification_email:
        db.add(
            MailMessage(
                key="team:" + reference,
                recipient=str(config().notification_email),
                locale="ru",
                kind="team",
                reference=reference,
            )
        )


def message_for(row):
    cfg = config()
    message = EmailMessage()
    message["From"] = str(cfg.smtp_from)
    message["To"] = row.recipient
    message["Date"] = formatdate(localtime=False, usegmt=True)
    message["Message-ID"] = f"<{row.id}@{urlsplit(cfg.site_origin).hostname}>"
    if row.kind == "team":
        message["Subject"] = f"Новая заявка ZILAL TRAVEL · {row.reference}"
        text = f"Заявка {row.reference} сохранена в CRM.\nОткройте рабочий кабинет: {cfg.site_origin}/admin/leads\nКонтакты клиента доступны только после входа."
    elif row.locale == "en":
        message["Subject"] = f"Your ZILAL TRAVEL enquiry · {row.reference}"
        text = f"We have received your travel wishes.\nYour reference: {row.reference}\nOur team will prepare a proposal. This is not a confirmed booking or a payment.\n{cfg.site_origin}/en/contacts"
    else:
        message["Subject"] = f"Ваша заявка ZILAL TRAVEL · {row.reference}"
        text = f"Мы получили ваши пожелания к путешествию.\nНомер обращения: {row.reference}\nКоманда подготовит предложение. Это не подтверждение бронирования и не оплата.\n{cfg.site_origin}/contacts"
    message.set_content(text)
    return message


def send_message(message):
    cfg = config()
    if not cfg.mail_enabled or not cfg.smtp_host or not cfg.smtp_from:
        raise RuntimeError("smtp_not_configured")
    if cfg.smtp_security not in {"starttls", "tls", "local"}:
        raise RuntimeError("smtp_security_invalid")
    if cfg.smtp_security == "local" and (
        cfg.app_env == "production" or cfg.smtp_host not in {"localhost", "127.0.0.1"}
    ):
        raise RuntimeError("smtp_tls_required")
    cls = smtplib.SMTP_SSL if cfg.smtp_security == "tls" else smtplib.SMTP
    options = {"timeout": 20}
    if cls is smtplib.SMTP_SSL:
        options["context"] = ssl.create_default_context()
    with cls(cfg.smtp_host, cfg.smtp_port, **options) as smtp:
        smtp.ehlo()
        if cfg.smtp_security == "starttls":
            smtp.starttls(context=ssl.create_default_context())
            smtp.ehlo()
        if cfg.smtp_username:
            smtp.login(cfg.smtp_username, cfg.smtp_password)
        smtp.send_message(message)


def deliver(limit=20):
    if not config().mail_enabled:
        return {"sent": 0, "failed": 0, "disabled": True}
    with SessionLocal() as db:
        db.execute(
            update(MailMessage)
            .where(
                MailMessage.status == "sending",
                MailMessage.attempts >= 5,
                MailMessage.next_attempt <= now(),
            )
            .values(status="failed", last_error="delivery_uncertain")
        )
        db.commit()
    result = {"sent": 0, "failed": 0}
    for _ in range(limit):
        with SessionLocal() as db:
            row = db.scalar(
                select(MailMessage)
                .where(
                    or_(MailMessage.status == "pending", MailMessage.status == "sending"),
                    MailMessage.next_attempt <= now(),
                    MailMessage.attempts < 5,
                )
                .order_by(MailMessage.next_attempt)
                .with_for_update(skip_locked=True)
                .limit(1)
            )
            if row is None:
                break
            row.status = "sending"
            row.attempts += 1
            row.next_attempt = now() + timedelta(minutes=5)
            db.commit()
            id, attempt = row.id, row.attempts
            message = message_for(row)
        error = ""
        try:
            send_message(message)
        except (OSError, smtplib.SMTPException, RuntimeError) as exc:
            # Never save server messages, passwords, email bodies or recipient addresses in errors.
            error = type(exc).__name__
        with SessionLocal() as db:
            row = db.scalar(select(MailMessage).where(MailMessage.id == id).with_for_update())
            if row.status != "sending" or row.attempts != attempt:
                continue
            row.status = "failed" if error and attempt >= 5 else "pending" if error else "sent"
            row.last_error = error
            row.next_attempt = now() + timedelta(minutes=min(60, 2**attempt))
            if not error:
                row.sent_at = now()
                # Once sent, no recipient needs to remain in the queue.
                row.recipient = ""
            db.commit()
        result["failed" if error else "sent"] += 1
    return result
