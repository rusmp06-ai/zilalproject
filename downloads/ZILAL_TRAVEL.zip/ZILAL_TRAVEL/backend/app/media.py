import io
import re
import warnings
from uuid import uuid4

from fastapi import APIRouter, Depends, HTTPException, Request
from fastapi.responses import Response
from PIL import Image, ImageOps, UnidentifiedImageError
from sqlalchemy import select, text

from app.auth import editor, writable
from app.config import config
from app.database import db_session
from app.media_storage import delete_media, read_media, write_media
from app.models import Audit, Content, Media, SiteSettings

router = APIRouter(prefix="/api/v1")
MEDIA_PATTERN = r"^/api/media/[a-f0-9-]{36}$"
MAX_UPLOAD = 8 * 1024 * 1024
Image.MAX_IMAGE_PIXELS = 25_000_000


def validate_media(db, url):
    if re.fullmatch(MEDIA_PATTERN, url):
        if not db.scalar(select(Media).where(Media.id == url.rsplit("/", 1)[1]).with_for_update()):
            raise HTTPException(422, "Изображение не найдено")


def prepare_image(source):
    try:
        with warnings.catch_warnings():
            warnings.simplefilter("error", Image.DecompressionBombWarning)
            with Image.open(io.BytesIO(source)) as original:
                if original.format not in {"JPEG", "PNG", "WEBP"} or getattr(
                    original, "is_animated", False
                ):
                    raise ValueError("Unsupported format")
                original.load()
                image = ImageOps.exif_transpose(original).convert("RGB")
                image.thumbnail((2560, 2560), Image.Resampling.LANCZOS)
                output = io.BytesIO()
                image.save(output, format="WEBP", quality=85, method=4)
    except (
        UnidentifiedImageError,
        OSError,
        ValueError,
        Image.DecompressionBombError,
        Image.DecompressionBombWarning,
    ) as exc:
        raise HTTPException(
            422, "Загрузите обычное изображение JPEG, PNG или WebP до 25 мегапикселей"
        ) from exc
    return output.getvalue(), image.width, image.height


@router.post("/admin/media", status_code=201)
async def upload(request: Request, auth=Depends(writable), db=Depends(db_session)):
    source = await request.body()
    if not source or len(source) > MAX_UPLOAD:
        raise HTTPException(413, "Допустим файл до 8 МБ")
    data, width, height = prepare_image(source)
    db.execute(text("SELECT pg_advisory_xact_lock_shared(715804294)"))
    id = str(uuid4())
    driver = config().media_storage
    write_media(id + ".webp", data, driver)
    row = Media(
        id=id,
        name=id + ".webp",
        storage_driver=driver,
        width=width,
        height=height,
        size=len(data),
    )
    try:
        db.add(row)
        db.add(Audit(user_id=auth[1].id, action="Загрузка изображения", entity="media", title=id))
        db.commit()
    except Exception:
        db.rollback()
        try:
            delete_media(id + ".webp", driver)
        except (HTTPException, OSError):
            pass  # Preserve the original failure; a failed cleanup may leave an unused object.
        raise
    return {
        "id": id,
        "url": "/api/media/" + id,
        "width": row.width,
        "height": row.height,
        "size": row.size,
    }


@router.get("/public/media/{id}")
def image(id: str, db=Depends(db_session)):
    if not re.fullmatch(r"[a-f0-9-]{36}", id):
        raise HTTPException(404)
    row = db.get(Media, id)
    if not row:
        raise HTTPException(404)
    return Response(read_media(row.name, row.storage_driver), media_type="image/webp")


@router.get("/admin/media")
def listing(auth=Depends(editor), db=Depends(db_session)):
    return [
        {"id": m.id, "url": "/api/media/" + m.id, "width": m.width, "height": m.height}
        for m in db.scalars(select(Media).order_by(Media.created_at.desc()).limit(100))
    ]


@router.delete("/admin/media/{id}")
def remove(id: str, auth=Depends(writable), db=Depends(db_session)):
    db.execute(text("SELECT pg_advisory_xact_lock_shared(715804294)"))
    row = db.scalar(select(Media).where(Media.id == id).with_for_update())
    if not row:
        raise HTTPException(404)
    url = "/api/media/" + id
    if db.scalar(select(Content.id).where(Content.image == url).limit(1)) or db.scalar(
        select(SiteSettings.id).where(SiteSettings.hero_image == url)
    ):
        raise HTTPException(409, "Изображение используется в материале или на главной")
    delete_media(row.name, row.storage_driver)
    db.delete(row)
    db.add(Audit(user_id=auth[1].id, action="Удаление изображения", entity="media", title=id))
    db.commit()
    return {"ok": True}
