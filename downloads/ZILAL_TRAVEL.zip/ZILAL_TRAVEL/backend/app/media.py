import io
import re
import warnings
from pathlib import Path
from uuid import uuid4

from fastapi import APIRouter, Depends, HTTPException, Request
from fastapi.responses import FileResponse
from PIL import Image, ImageOps, UnidentifiedImageError
from sqlalchemy import select, text

from app.auth import editor, writable
from app.config import config
from app.database import db_session
from app.models import Audit, Content, Media, SiteSettings

router = APIRouter(prefix="/api/v1")
MEDIA_PATTERN = r"^/api/media/[a-f0-9-]{36}$"
MAX_UPLOAD = 8 * 1024 * 1024
Image.MAX_IMAGE_PIXELS = 25_000_000


def directory():
    c = config()
    if c.app_env == "production" and not c.media_persistent:
        raise HTTPException(503, "Постоянное хранилище фотографий ещё не настроено")
    return Path(c.media_root).resolve()


def validate_media(db, url):
    if re.fullmatch(MEDIA_PATTERN, url):
        if not db.scalar(select(Media).where(Media.id == url.rsplit("/", 1)[1]).with_for_update()):
            raise HTTPException(422, "Изображение не найдено")


@router.post("/admin/media", status_code=201)
async def upload(request: Request, auth=Depends(writable), db=Depends(db_session)):
    source = await request.body()
    if not source or len(source) > MAX_UPLOAD:
        raise HTTPException(413, "Допустим файл до 8 МБ")
    try:
        with warnings.catch_warnings():
            warnings.simplefilter("error", Image.DecompressionBombWarning)
            with Image.open(io.BytesIO(source)) as original:
                if original.format not in {"JPEG", "PNG", "WEBP"} or getattr(
                    original, "is_animated", False
                ):
                    raise ValueError("Unsupported format")
                original.load()
                image = ImageOps.exif_transpose(original).convert("RGB")
                image.thumbnail((2560, 2560), Image.Resampling.LANCZOS)
                output = io.BytesIO()
                image.save(output, format="WEBP", quality=85, method=4)
    except (
        UnidentifiedImageError,
        OSError,
        ValueError,
        Image.DecompressionBombError,
        Image.DecompressionBombWarning,
    ) as exc:
        raise HTTPException(
            422, "Загрузите обычное изображение JPEG, PNG или WebP до 25 мегапикселей"
        ) from exc
    db.execute(text("SELECT pg_advisory_xact_lock_shared(715804294)"))
    root = directory()
    root.mkdir(parents=True, exist_ok=True)
    id = str(uuid4())
    path = root / (id + ".webp")
    data = output.getvalue()
    path.write_bytes(data)
    row = Media(id=id, name=id + ".webp", width=image.width, height=image.height, size=len(data))
    try:
        db.add(row)
        db.add(Audit(user_id=auth[1].id, action="Загрузка изображения", entity="media", title=id))
        db.commit()
    except Exception:
        path.unlink(missing_ok=True)
        raise
    return {
        "id": id,
        "url": "/api/media/" + id,
        "width": row.width,
        "height": row.height,
        "size": row.size,
    }


@router.get("/public/media/{id}")
def image(id: str, db=Depends(db_session)):
    if not re.fullmatch(r"[a-f0-9-]{36}", id):
        raise HTTPException(404)
    row = db.get(Media, id)
    if not row:
        raise HTTPException(404)
    path = directory() / row.name
    if not path.is_file():
        raise HTTPException(404)
    return FileResponse(path, media_type="image/webp")


@router.get("/admin/media")
def listing(auth=Depends(editor), db=Depends(db_session)):
    return [
        {"id": m.id, "url": "/api/media/" + m.id, "width": m.width, "height": m.height}
        for m in db.scalars(select(Media).order_by(Media.created_at.desc()).limit(100))
    ]


@router.delete("/admin/media/{id}")
def remove(id: str, auth=Depends(writable), db=Depends(db_session)):
    db.execute(text("SELECT pg_advisory_xact_lock_shared(715804294)"))
    row = db.scalar(select(Media).where(Media.id == id).with_for_update())
    if not row:
        raise HTTPException(404)
    url = "/api/media/" + id
    if db.scalar(select(Content.id).where(Content.image == url).limit(1)) or db.scalar(
        select(SiteSettings.id).where(SiteSettings.hero_image == url)
    ):
        raise HTTPException(409, "Изображение используется в материале или на главной")
    path = directory() / row.name
    db.delete(row)
    db.add(Audit(user_id=auth[1].id, action="Удаление изображения", entity="media", title=id))
    db.commit()
    path.unlink(missing_ok=True)
    return {"ok": True}
