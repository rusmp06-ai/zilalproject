"""Private backend-owned tables: never expose CRM/auth through Supabase Data API."""

from sqlalchemy import text

from app.models import Base


def secure_tables(db):
    # Supabase creates these roles. Don't alter any tables owned by Supabase itself.
    roles = list(
        db.scalars(
            text(
                "SELECT rolname FROM pg_roles WHERE rolname IN ('anon', 'authenticated', 'service_role')"
            )
        )
    )
    if not {"anon", "authenticated"}.issubset(roles):
        raise RuntimeError("This database does not have the Supabase API roles")
    for name in ["alembic_version", *Base.metadata.tables]:
        db.execute(text(f'ALTER TABLE public."{name}" ENABLE ROW LEVEL SECURITY'))
        for role in roles:
            db.execute(text(f'REVOKE ALL PRIVILEGES ON TABLE public."{name}" FROM "{role}"'))
        db.execute(text(f'REVOKE ALL PRIVILEGES ON TABLE public."{name}" FROM PUBLIC'))
    return len(Base.metadata.tables) + 1
