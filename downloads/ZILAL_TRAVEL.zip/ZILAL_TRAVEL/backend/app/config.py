import re
from functools import lru_cache
from typing import Literal

from pydantic import EmailStr, Field, SecretStr, field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


class Config(BaseSettings):
    database_url: str
    site_origin: str = "http://localhost:3000"
    app_env: str = "development"
    media_storage: Literal["local", "supabase"] = "local"
    supabase_url: str = ""
    supabase_service_key: SecretStr = SecretStr("")
    supabase_storage_bucket: str = "zilal-media"
    media_root: str = "var/media"
    media_persistent: bool = False
    session_hours: int = Field(default=12, ge=1, le=168)
    payment_instructions: str = Field(default="", max_length=3000)
    payment_instructions_en: str = Field(default="", max_length=3000)
    backup_root: str = "var/backups"
    backup_keep: int = Field(default=7, ge=1, le=365)
    backup_driver: str = "pg_dump"
    pg_dump_path: str = "pg_dump"
    backup_docker_service: str = "postgres"
    smtp_host: str = ""
    smtp_port: int = Field(default=587, ge=1, le=65535)
    smtp_security: str = "starttls"
    smtp_username: str = ""
    smtp_password: str = ""
    smtp_from: EmailStr | None = None
    notification_email: EmailStr | None = None
    mail_enabled: bool = False

    @field_validator("supabase_url")
    @classmethod
    def valid_supabase_url(cls, value):
        if value and not re.fullmatch(r"https://[a-z0-9-]+\.supabase\.co/?", value):
            raise ValueError("Use the HTTPS project URL from Supabase settings")
        return value.rstrip("/")

    @field_validator("supabase_storage_bucket")
    @classmethod
    def valid_bucket(cls, value):
        if not re.fullmatch(r"[a-z0-9][a-z0-9-]{0,62}", value):
            raise ValueError("Use a simple lowercase bucket name")
        return value

    @field_validator("database_url")
    @classmethod
    def sqlalchemy_postgres(cls, value):
        if value.startswith("postgresql://"):
            return value.replace("postgresql://", "postgresql+psycopg://", 1)
        if value.startswith("postgres://"):
            return value.replace("postgres://", "postgresql+psycopg://", 1)
        return value

    @field_validator("smtp_from", "notification_email", mode="before")
    @classmethod
    def empty_optional_email(cls, value):
        return None if isinstance(value, str) and not value.strip() else value

    model_config = SettingsConfigDict(env_file=".env", extra="ignore", hide_input_in_errors=True)


@lru_cache
def config() -> Config:
    return Config()
