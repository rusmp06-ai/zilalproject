import json
from pathlib import Path

from fastapi import HTTPException
from sqlalchemy import select

from app.models import Content, SiteTranslation, Translation
from app.schemas import ENTITIES
from app.translations import TranslationInput


def import_translations(db, file, apply=False):
    path = Path(file)
    if path.stat().st_size > 5_000_000:
        raise ValueError("Translation file is too large")
    data = json.loads(path.read_text(encoding="utf-8"))
    if data.get("locale") != "en" or data.get("version") != 1:
        raise ValueError("Unsupported translation file")
    # Use the same validation and persistence logic, but do not commit per record.
    from app.translations import save_translation

    count = skipped = 0
    for entity in ENTITIES:
        for value in data["collections"].get(entity, []):
            row = db.scalar(
                select(Content)
                .where(Content.entity == entity, Content.slug == value["slug"])
                .with_for_update()
            )
            if not row or db.get(Translation, (row.id, "en")):
                skipped += 1
                continue
            payload = TranslationInput(
                title=value["title"],
                description=value.get("description", ""),
                fields=value["fields"],
                version=row.version,
                published=value.get("published", False),
            )
            save_translation(db, row, "en", payload, None)
            count += 1
    if not db.get(SiteTranslation, "en"):
        settings = data["settings"]
        if (
            not settings["heroTitle"].strip()
            or len(settings["heroTitle"]) > 300
            or not settings["heroDescription"].strip()
            or len(settings["heroDescription"]) > 3000
        ):
            raise HTTPException(422, "Invalid English Hero")
        db.add(
            SiteTranslation(
                locale="en",
                address=settings.get("address", ""),
                hero_title=settings["heroTitle"],
                hero_description=settings["heroDescription"],
            )
        )
    if apply:
        db.commit()
    else:
        db.rollback()
    return {"created": count, "skipped": skipped}
