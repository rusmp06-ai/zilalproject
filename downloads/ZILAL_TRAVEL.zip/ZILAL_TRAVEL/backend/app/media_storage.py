"""Local disk or private Supabase Storage, always accessed by the backend."""

import json
import re
from pathlib import Path
from urllib.error import HTTPError, URLError
from urllib.parse import quote
from urllib.request import HTTPRedirectHandler, Request, build_opener

from fastapi import HTTPException

from app.config import config


class NoRedirect(HTTPRedirectHandler):
    # Never forward a service credential to a redirected destination.
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


def directory():
    cfg = config()
    if cfg.app_env == "production" and not cfg.media_persistent:
        raise HTTPException(503, "Постоянное хранилище фотографий ещё не настроено")
    return Path(cfg.media_root).resolve()


def object_name(name):
    if not re.fullmatch(r"[a-f0-9-]{36}\.webp", name):
        raise HTTPException(422, "Недопустимое имя фотографии")
    return name


def supabase_request(method, name, data=None):
    cfg = config()
    if not cfg.supabase_url or not cfg.supabase_service_key.get_secret_value():
        raise HTTPException(503, "Supabase Storage ещё не настроен")
    name = object_name(name)
    prefix = "object/authenticated/" if method == "GET" else "object/"
    url = (
        cfg.supabase_url.rstrip("/")
        + "/storage/v1/"
        + prefix
        + quote(cfg.supabase_storage_bucket, safe="")
        + "/"
        + quote(name, safe="")
    )
    if method == "DELETE":
        # Supabase removes a list of exact object keys at the bucket endpoint.
        url = (
            cfg.supabase_url.rstrip("/")
            + "/storage/v1/object/"
            + quote(cfg.supabase_storage_bucket, safe="")
        )
        data = json.dumps({"prefixes": [name]}).encode()
    secret = cfg.supabase_service_key.get_secret_value()
    request = Request(
        url,
        data=data,
        method=method,
        headers={
            "apikey": secret,
            "Authorization": "Bearer " + secret,
            "Content-Type": "application/json" if method == "DELETE" else "image/webp",
            "x-upsert": "false",
        },
    )
    try:
        with build_opener(NoRedirect()).open(request, timeout=30) as response:
            # Our converted files are bounded by the accepted upload dimensions.
            body = response.read(32 * 1024 * 1024 + 1)
            if len(body) > 32 * 1024 * 1024:
                raise HTTPException(502, "Ответ хранилища фотографий слишком большой")
            return body
    except HTTPError as exc:
        if method == "GET" and exc.code == 404:
            raise HTTPException(404, "Фото не найдено в хранилище") from None
        raise HTTPException(503, "Хранилище фотографий Supabase временно недоступно") from None
    except (URLError, OSError):
        raise HTTPException(503, "Хранилище фотографий Supabase временно недоступно") from None


def write_media(name, data, driver):
    object_name(name)
    if driver == "supabase":
        supabase_request("POST", name, data)
    elif driver == "local":
        root = directory()
        root.mkdir(parents=True, exist_ok=True)
        (root / name).write_bytes(data)
    else:
        raise HTTPException(503, "Неизвестное хранилище фотографий")


def read_media(name, driver):
    object_name(name)
    if driver == "supabase":
        return supabase_request("GET", name)
    if driver != "local":
        raise HTTPException(503, "Неизвестное хранилище фотографий")
    path = directory() / name
    if not path.is_file():
        raise HTTPException(404, "Фото не найдено в хранилище")
    return path.read_bytes()


def delete_media(name, driver):
    object_name(name)
    if driver == "supabase":
        supabase_request("DELETE", name)
    elif driver == "local":
        (directory() / name).unlink(missing_ok=True)
    else:
        raise HTTPException(503, "Неизвестное хранилище фотографий")
