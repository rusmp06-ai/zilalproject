"""Import embedded demo photos; dry runs never write local/cloud media."""

import base64
import binascii
import hashlib
import re
from uuid import uuid4

from fastapi import HTTPException
from sqlalchemy import text

from app.config import config
from app.media import MAX_UPLOAD, prepare_image
from app.media_storage import delete_media, write_media
from app.models import Media


class PhotoImport:
    def __init__(self, db):
        self.db = db
        self.photos = {}
        self.written = []

    def image(self, source):
        if source.startswith("local-photo:"):
            raise ValueError(
                "Экспортируйте JSON из новой админки: нужны сами фото, а не ссылки браузера"
            )
        if not source.startswith("data:"):
            return source
        if len(source) > 12_000_000 or not re.fullmatch(
            r"data:image/(?:jpeg|png|webp);base64,[A-Za-z0-9+/]+={0,2}", source
        ):
            raise ValueError("Недопустимая фотография в резервной копии")
        try:
            original = base64.b64decode(source.split(",", 1)[1], validate=True)
        except binascii.Error:
            raise ValueError("Повреждённая фотография в резервной копии") from None
        if not original or len(original) > MAX_UPLOAD:
            raise ValueError("Допустима фотография до 8 МБ")
        digest = hashlib.sha256(original).hexdigest()
        if digest not in self.photos:
            data, width, height = prepare_image(original)
            self.db.execute(text("SELECT pg_advisory_xact_lock_shared(715804294)"))
            row = Media(
                id=str(uuid4()),
                name="",
                storage_driver=config().media_storage,
                width=width,
                height=height,
                size=len(data),
            )
            row.name = row.id + ".webp"
            self.db.add(row)
            self.db.flush()
            self.photos[digest] = (row, data)
        return "/api/media/" + self.photos[digest][0].id

    def upload(self):
        for row, data in self.photos.values():
            write_media(row.name, data, row.storage_driver)
            self.written.append((row.name, row.storage_driver))

    def cleanup(self):
        for name, driver in self.written:
            try:
                delete_media(name, driver)
            except (HTTPException, OSError):
                pass  # A failed cleanup can leave an unused object, never a public content record.
