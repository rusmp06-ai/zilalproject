import "server-only";
import type { Metadata } from "next";
import { requestLocale, publicData } from "./server";
import type { Item } from "@/types/platform";
export function siteURL() {
  const url = new URL(process.env.SITE_ORIGIN || "http://localhost:3000");
  if (
    !["http:", "https:"].includes(url.protocol) ||
    url.username ||
    url.password ||
    url.search ||
    url.hash ||
    url.pathname !== "/"
  )
    throw Error("SITE_ORIGIN must be a plain site origin");
  return url;
}
export function indexingEnabled() {
  const enabled = process.env.INDEXING_ENABLED === "true";
  if (
    enabled &&
    (process.env.PLATFORM_MODE !== "server" ||
      siteURL().protocol !== "https:" ||
      ["localhost", "127.0.0.1"].includes(siteURL().hostname))
  )
    throw Error("Indexing requires a configured HTTPS server site");
  return enabled;
}
export async function itemMetadata(
  item: Item | undefined,
  entity: string,
  slug: string,
): Promise<Metadata> {
  const title = `${item?.fields.seoTitle || item?.title || "ZILAL TRAVEL"} — ZILAL TRAVEL`;
  const description = item?.fields.seoDescription || item?.description;
  const locale = await requestLocale();
  const path = `/${entity}/${encodeURIComponent(slug)}`;
  const url = new URL((locale === "en" ? "/en" : "") + path, siteURL()).href;
  const english = await publicData("en");
  const hasEnglish = english.collections[entity as "tours"].some(
    (row) => row.slug === slug && row.status === "Опубликован",
  );
  return {
    title,
    description,
    alternates: {
      canonical: url,
      languages: { ru: path, ...(hasEnglish ? { en: "/en" + path } : {}) },
    },
    openGraph: {
      title,
      description,
      url,
      type: entity === "journal" ? "article" : "website",
      locale: locale === "en" ? "en_GB" : "ru_RU",
    },
  };
}
