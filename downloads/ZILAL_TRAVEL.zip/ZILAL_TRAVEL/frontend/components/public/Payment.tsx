"use client";
import { useEffect, useRef, useState } from "react";
import { api } from "@/services/client";
import { useLocale } from "@/components/localization/LocaleProvider";
type Details = {
  reference: string;
  remaining: string;
  currency: string;
  instructions: string;
  paid: boolean;
};
export function Payment() {
  const { ui, locale } = useLocale();
  const savedToken = useRef("");
  const [details, setDetails] = useState<Details>();
  const [failed, setFailed] = useState(false);
  useEffect(() => {
    savedToken.current ||=
      new URLSearchParams(location.hash.slice(1)).get("token") || "";
    const token = savedToken.current;
    // Fragment stays out of server logs and referrer headers.
    history.replaceState(null, "", location.pathname);
    if (!token) {
      setFailed(true);
      return;
    }
    let active = true;
    api<Details>("public/payment-info", {
      method: "POST",
      body: JSON.stringify({ token, locale }),
    })
      .then((v) => {
        if (active) setDetails(v);
      })
      .catch(() => {
        if (active) setFailed(true);
      });
    return () => {
      active = false;
    };
  }, [locale]);
  return (
    <article className="container public-page">
      <h1>{ui.payment.title}</h1>
      {failed ? (
        <p role="alert">{ui.payment.invalid}</p>
      ) : !details ? (
        <p role="status">{ui.payment.loading}</p>
      ) : details.paid ? (
        <p role="status">{ui.payment.paid}</p>
      ) : (
        <>
          <p>{ui.payment.remaining}</p>
          <h2>
            {new Intl.NumberFormat(locale, {
              style: "currency",
              currency: details.currency,
            }).format(Number(details.remaining))}
          </h2>
          <p>
            {ui.payment.reference}: <strong>{details.reference}</strong>
          </p>
          <h2>{ui.payment.instructions}</h2>
          <p style={{ whiteSpace: "pre-line" }}>{details.instructions}</p>
          <p>{ui.payment.note}</p>
        </>
      )}
    </article>
  );
}
