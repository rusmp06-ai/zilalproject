"use client";
import { useLocale } from "@/components/localization/LocaleProvider";
import { Header } from "@/components/layout/Header";
import { Footer } from "@/components/layout/Footer";

export function PublicShell({ children }: { children: React.ReactNode }) {
  const { t } = useLocale();
  return (
    <div className="warm-site">
      <a className="skip-link" href="#main">
        {t.skip}
      </a>
      <div id="top" />
      <Header />
      <main id="main">{children}</main>
      <Footer />
    </div>
  );
}
