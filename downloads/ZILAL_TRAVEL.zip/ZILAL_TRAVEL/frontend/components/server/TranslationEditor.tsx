"use client";
import { useState, type FormEvent } from "react";
import { api, APIError } from "@/services/client";
import { staffRequest } from "./AccessTools";
import { ui } from "@/data/content/platform";
import { configs } from "@/data/admin/config";
import type { Item, Entity } from "@/types/platform";
import { useUnsavedChanges } from "@/hooks/useUnsavedChanges";
const textKeys = [
  "label",
  "body",
  "season",
  "audience",
  "pace",
  "preparation",
  "startPoint",
  "priceNote",
  "stay",
  "transport",
  "seoTitle",
  "seoDescription",
  "itinerary",
  "included",
  "excluded",
  "faq",
  "alt",
  "quote",
  "author",
  "readingTime",
];
export function TranslationEditor({
  entity,
  item,
}: {
  entity: Entity;
  item: Item;
}) {
  const [open, setOpen] = useState(false);
  const [draft, setDraft] = useState<Item>();
  const [dirty, setDirty] = useState(false);
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState("");
  useUnsavedChanges(dirty);
  const fields = configs[entity].fields.filter((f) => textKeys.includes(f.key));
  async function load() {
    setBusy(true);
    setMessage("");
    try {
      const current = await api<Item>(
        `admin/translations/${entity}/${item.id}/ru`,
      );
      try {
        setDraft(await api<Item>(`admin/translations/${entity}/${item.id}/en`));
      } catch (e) {
        if (!(e instanceof APIError) || e.status !== 404) throw e;
        setDraft({
          ...current,
          title: "",
          description: "",
          translationPublished: false,
          fields: Object.fromEntries(fields.map((f) => [f.key, ""])),
        });
      }
      setOpen(true);
    } catch (e) {
      setMessage(e instanceof Error ? e.message : ui.backend.unavailable);
    } finally {
      setBusy(false);
    }
  }
  async function save(e: FormEvent) {
    e.preventDefault();
    if (!draft || busy) return;
    setBusy(true);
    setMessage("");
    try {
      const next = await staffRequest<Item>(
        `admin/translations/${entity}/${item.id}/en`,
        "PUT",
        {
          title: draft.title,
          description: draft.description,
          fields: Object.fromEntries(
            fields.map((f) => [f.key, draft.fields[f.key] || ""]),
          ),
          version: draft.version,
          published: draft.translationPublished ?? false,
        },
      );
      setDraft(next);
      setDirty(false);
      setMessage(ui.operations.translationSaved);
      // Refresh the main provider without replacing an unsaved Russian draft.
      window.dispatchEvent(new Event("focus"));
    } catch (e) {
      setMessage(e instanceof Error ? e.message : ui.backend.unavailable);
    } finally {
      setBusy(false);
    }
  }
  return (
    <section className="admin-panel">
      <h2>{ui.operations.language}</h2>
      <p>{ui.operations.translationHelp}</p>
      {!open && (
        <button className="small-button" disabled={busy} onClick={load}>
          {ui.operations.english}
        </button>
      )}
      {open && draft && (
        <form className="planning-form" onSubmit={save}>
          <label>
            {ui.admin.titleField}
            <input
              required
              maxLength={300}
              value={draft.title}
              onChange={(e) => {
                setDraft({ ...draft, title: e.target.value });
                setDirty(true);
              }}
            />
          </label>
          <label>
            {ui.admin.descriptionField}
            <textarea
              maxLength={3000}
              value={draft.description}
              onChange={(e) => {
                setDraft({ ...draft, description: e.target.value });
                setDirty(true);
              }}
            />
          </label>
          {fields.map((f) => (
            <label key={f.key}>
              {f.label}
              <textarea
                maxLength={f.type === "textarea" ? 20000 : 300}
                value={draft.fields[f.key] || ""}
                onChange={(e) => {
                  setDraft({
                    ...draft,
                    fields: { ...draft.fields, [f.key]: e.target.value },
                  });
                  setDirty(true);
                }}
              />
            </label>
          ))}
          <label className="checkbox-label">
            <input
              type="checkbox"
              checked={draft.translationPublished ?? false}
              onChange={(e) => {
                setDraft({ ...draft, translationPublished: e.target.checked });
                setDirty(true);
              }}
            />
            {ui.operations.publishTranslation}
          </label>
          <button className="button" disabled={busy}>
            {busy ? ui.admin.saving : ui.operations.translationSave}
          </button>
        </form>
      )}
      {message && <p role="status">{message}</p>}
    </section>
  );
}
