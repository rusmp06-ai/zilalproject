"use client";
import { useEffect, useState, type FormEvent } from "react";
import Link from "next/link";
import { api } from "@/services/client";
import { ui } from "@/data/content/platform";

export async function staffRequest<T>(
  path: string,
  method: string,
  body?: unknown,
) {
  const { csrf } = await api<{ csrf: string }>("auth/me");
  return api<T>(path, {
    method,
    headers: { "X-CSRF-Token": csrf },
    body: body === undefined ? undefined : JSON.stringify(body),
  });
}
export function InviteLink({ id }: { id: string }) {
  const [url, setURL] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  return (
    <section className="admin-panel">
      <h2>{ui.operations.invite}</h2>
      <p>{ui.operations.inviteHelp}</p>
      <button
        className="small-button"
        disabled={busy}
        onClick={async () => {
          setBusy(true);
          setError("");
          setURL("");
          try {
            const r = await staffRequest<{ url: string }>(
              `admin/employees/${encodeURIComponent(id)}/invite`,
              "POST",
            );
            setURL(r.url);
          } catch (e) {
            setError(e instanceof Error ? e.message : ui.backend.unavailable);
          } finally {
            setBusy(false);
          }
        }}
      >
        {ui.operations.inviteCreate}
      </button>
      {url && (
        <label>
          {ui.operations.invite}
          <input readOnly value={url} onFocus={(e) => e.target.select()} />
        </label>
      )}
      {error && (
        <p role="alert" className="form-error">
          {error}
        </p>
      )}
    </section>
  );
}
export function PasswordForm({ change = false }: { change?: boolean }) {
  const [token, setToken] = useState("");
  const [currentPassword, setCurrentPassword] = useState("");
  const [password, setPassword] = useState("");
  const [confirmation, setConfirmation] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const [done, setDone] = useState(false);
  useEffect(() => {
    if (!change) {
      setToken(new URLSearchParams(location.hash.slice(1)).get("token") || "");
      history.replaceState(null, "", location.pathname);
    }
  }, [change]);
  async function submit(e: FormEvent) {
    e.preventDefault();
    setError("");
    if (password !== confirmation) {
      setError(ui.operations.passwordMismatch);
      return;
    }
    if (busy) return;
    setBusy(true);
    try {
      if (change)
        await staffRequest("auth/change-password", "POST", {
          currentPassword,
          password,
        });
      else
        await api("auth/reset-password", {
          method: "POST",
          body: JSON.stringify({ token, password }),
        });
      setPassword("");
      setCurrentPassword("");
      setConfirmation("");
      setDone(true);
      if (change) window.location.assign("/login");
    } catch (e) {
      setError(e instanceof Error ? e.message : ui.backend.unavailable);
    } finally {
      setBusy(false);
    }
  }
  return (
    <div className={change ? "admin-panel" : "container public-page"}>
      <h1>{change ? ui.operations.account : ui.operations.resetTitle}</h1>
      {done ? (
        <p role="status">
          {ui.operations.passwordSaved}{" "}
          <Link href="/login">{ui.operations.login}</Link>
        </p>
      ) : (
        <form className="planning-form" onSubmit={submit}>
          {change && (
            <label>
              {ui.operations.currentPassword}
              <input
                type="password"
                autoComplete="current-password"
                required
                maxLength={200}
                value={currentPassword}
                onChange={(e) => setCurrentPassword(e.target.value)}
              />
            </label>
          )}
          <label>
            {ui.operations.password}
            <input
              type="password"
              autoComplete="new-password"
              required
              minLength={12}
              maxLength={200}
              value={password}
              onChange={(e) => setPassword(e.target.value)}
            />
          </label>
          <label>
            {ui.operations.passwordConfirm}
            <input
              type="password"
              autoComplete="new-password"
              required
              minLength={12}
              maxLength={200}
              value={confirmation}
              onChange={(e) => setConfirmation(e.target.value)}
            />
          </label>
          {error && (
            <p role="alert" className="form-error">
              {error}
            </p>
          )}
          <button className="button" disabled={busy || (!change && !token)}>
            {busy
              ? ui.admin.saving
              : change
                ? ui.operations.changePassword
                : ui.operations.resetTitle}
          </button>
          {!change && <Link href="/login">{ui.operations.login}</Link>}
        </form>
      )}
    </div>
  );
}

export function LeadConversion({
  id,
  version,
}: {
  id: string;
  version: number;
}) {
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  return (
    <button
      type="button"
      className="small-button"
      disabled={busy}
      onClick={async () => {
        setBusy(true);
        setError("");
        try {
          const result = await staffRequest<{ customer: { id: string } }>(
            `admin/leads/${encodeURIComponent(id)}/convert`,
            "POST",
            { version },
          );
          window.location.assign(
            `/admin/customers/${encodeURIComponent(result.customer.id)}`,
          );
        } catch (e) {
          setError(e instanceof Error ? e.message : ui.backend.unavailable);
        } finally {
          setBusy(false);
        }
      }}
    >
      {error || (busy ? ui.admin.saving : ui.operations.convert)}
    </button>
  );
}
