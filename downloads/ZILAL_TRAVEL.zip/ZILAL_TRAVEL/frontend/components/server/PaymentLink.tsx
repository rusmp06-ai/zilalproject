"use client";
import { useState } from "react";
import { staffRequest } from "./AccessTools";
import { ui } from "@/data/content/platform";
export function PaymentLink({ id }: { id: string }) {
  const [url, setURL] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  return (
    <section className="admin-panel">
      <h2>{ui.payment.linkTitle}</h2>
      <p>{ui.payment.linkHelp}</p>
      <button
        className="small-button"
        disabled={busy}
        onClick={async () => {
          setBusy(true);
          setError("");
          setURL("");
          try {
            setURL(
              (
                await staffRequest<{ url: string }>(
                  `admin/bookings/${id}/payment-link`,
                  "POST",
                )
              ).url,
            );
          } catch (e) {
            setError(e instanceof Error ? e.message : ui.backend.unavailable);
          } finally {
            setBusy(false);
          }
        }}
      >
        {ui.payment.createLink}
      </button>
      {url && (
        <>
          <label>
            {ui.payment.linkTitle} · RU
            <input readOnly value={url} onFocus={(e) => e.target.select()} />
          </label>
          <label>
            {ui.payment.linkTitle} · EN
            <input
              readOnly
              value={url.replace("/payment#", "/en/payment#")}
              onFocus={(e) => e.target.select()}
            />
          </label>
        </>
      )}
      {error && <p role="alert">{error}</p>}
    </section>
  );
}
