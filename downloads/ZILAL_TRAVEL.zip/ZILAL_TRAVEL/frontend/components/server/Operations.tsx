"use client";
import { useEffect, useState, type FormEvent } from "react";
import { api } from "@/services/client";
import { staffRequest } from "./AccessTools";
import { useUnsavedChanges } from "@/hooks/useUnsavedChanges";
import { ui } from "@/data/content/platform";

type Status = {
  workerActive: boolean;
  mailEnabled: boolean;
  mailConfigured: boolean;
  backupKeep: number;
  mailCounts: Record<string, number>;
  services: Record<string, { successAt: string | null; error: string }>;
};
type English = {
  address: string;
  heroTitle: string;
  heroDescription: string;
  version: number;
};
export function Operations() {
  const [status, setStatus] = useState<Status>();
  const [error, setError] = useState("");
  async function load() {
    try {
      setStatus(await api<Status>("admin/operations"));
      setError("");
    } catch (e) {
      setError(e instanceof Error ? e.message : ui.backend.unavailable);
    }
  }
  useEffect(() => {
    void load();
    const timer = setInterval(load, 60000);
    return () => clearInterval(timer);
  }, []);
  const time = (value: string | null | undefined) =>
    value
      ? new Intl.DateTimeFormat("ru", {
          dateStyle: "short",
          timeStyle: "short",
        }).format(new Date(value))
      : ui.operationsExtras.never;
  return (
    <section className="admin-panel">
      <h2>{ui.operationsExtras.title}</h2>
      {status && (
        <>
          <p>
            {status.workerActive
              ? ui.operationsExtras.running
              : ui.operationsExtras.stopped}
          </p>
          <dl>
            <dt>{ui.operationsExtras.backup}</dt>
            <dd>
              {time(status.services.backup?.successAt)}
              {status.services.backup?.error &&
                ` · ${ui.operationsExtras.failed}`}
            </dd>
            <dt>{ui.operationsExtras.cleanup}</dt>
            <dd>{time(status.services.cleanup?.successAt)}</dd>
            <dt>{ui.operationsExtras.mail}</dt>
            <dd>
              {status.mailEnabled && status.mailConfigured
                ? ui.operationsExtras.enabled
                : ui.operationsExtras.disabled}
            </dd>
            <dt>{ui.operationsExtras.queue}</dt>
            <dd>
              {status.mailCounts.pending || 0} / {status.mailCounts.failed || 0}
            </dd>
          </dl>
          <p>
            {ui.operationsExtras.retention.replace(
              "{count}",
              String(status.backupKeep),
            )}
          </p>
        </>
      )}
      <p>{ui.operationsExtras.privateBackup}</p>
      <button className="small-button" onClick={load}>
        {ui.operationsExtras.refresh}
      </button>
      {error && <p role="alert">{error}</p>}
    </section>
  );
}
export function EnglishSettings() {
  const [value, setValue] = useState<English>();
  const [dirty, setDirty] = useState(false);
  const [message, setMessage] = useState("");
  const [busy, setBusy] = useState(false);
  useUnsavedChanges(dirty);
  useEffect(() => {
    api<English>("admin/site-translation/en")
      .then(setValue)
      .catch((e) => setMessage(e.message));
  }, []);
  async function save(e: FormEvent) {
    e.preventDefault();
    if (!value || busy) return;
    setBusy(true);
    try {
      setValue(
        await staffRequest<English>("admin/site-translation/en", "PUT", value),
      );
      setDirty(false);
      setMessage(ui.operations.translationSaved);
    } catch (e) {
      setMessage(e instanceof Error ? e.message : ui.backend.unavailable);
    } finally {
      setBusy(false);
    }
  }
  return (
    <section className="admin-panel">
      <h2>{ui.operationsExtras.englishHome}</h2>
      {value && (
        <form className="planning-form" onSubmit={save}>
          <label>
            {ui.admin.address}
            <input
              maxLength={300}
              value={value.address}
              onChange={(e) => {
                setValue({ ...value, address: e.target.value });
                setDirty(true);
              }}
            />
          </label>
          <label>
            {ui.admin.heroTitle}
            <textarea
              required
              maxLength={300}
              value={value.heroTitle}
              onChange={(e) => {
                setValue({ ...value, heroTitle: e.target.value });
                setDirty(true);
              }}
            />
          </label>
          <label>
            {ui.admin.heroDescription}
            <textarea
              maxLength={3000}
              value={value.heroDescription}
              onChange={(e) => {
                setValue({ ...value, heroDescription: e.target.value });
                setDirty(true);
              }}
            />
          </label>
          <button className="button" disabled={busy}>
            {busy ? ui.admin.saving : ui.admin.save}
          </button>
        </form>
      )}
      {message && <p role="status">{message}</p>}
    </section>
  );
}
