"use client";
import { useState } from "react";
import Image from "next/image";
import { staffRequest } from "./AccessTools";
import { api } from "@/services/client";
import { compressPhoto } from "@/lib/photos";
import { ui } from "@/data/content/platform";
export function ImageUpload({ onUpload, local = false, onBusy }: {
  onUpload: (url: string) => void;
  local?: boolean;
  onBusy?: (busy: boolean) => void;
}) {
  const [busy, setBusy] = useState(false);
  const [images, setImages] = useState<{ id: string; url: string }[]>();
  const [error, setError] = useState("");
  return (
    <div>
      <label>
        {ui.operations.upload}
        <input
          type="file"
          accept="image/jpeg,image/png,image/webp"
          disabled={busy}
          onChange={async (e) => {
            const file = e.target.files?.[0];
            e.target.value = "";
            if (!file) return;
            setError("");
            setBusy(true);
            onBusy?.(true);
            try {
              if (file.size > 8 * 1024 * 1024)
                throw Error(ui.operations.uploadHelp);
              if (local) {
                onUpload(await compressPhoto(file));
                return;
              }
              const { csrf } = await api<{ csrf: string }>("auth/me");
              const r = await fetch("/api/backend/admin/media", {
                method: "POST",
                headers: {
                  "Content-Type": "application/octet-stream",
                  "X-CSRF-Token": csrf,
                },
                body: file,
                signal: AbortSignal.timeout(65000),
              });
              const data = await r.json();
              if (!r.ok) throw Error(data.detail || ui.operations.uploadFailed);
              onUpload(data.url);
            } catch (e) {
              setError(
                e instanceof Error ? e.message : ui.operations.uploadFailed,
              );
            } finally {
              setBusy(false);
              onBusy?.(false);
            }
          }}
        />
      </label>
      <p className="demo-note">
        {busy ? ui.admin.saving : local ? ui.operations.localPhotoHelp : ui.operations.uploadHelp}
        {!busy && <> {ui.operations.photoSaveHelp}</>}
      </p>
      {!local && <button
        className="small-button"
        type="button"
        disabled={busy}
        onClick={async () => {
          setBusy(true);
          setError("");
          try {
            setImages(await api<{ id: string; url: string }[]>("admin/media"));
          } catch (e) {
            setError(
              e instanceof Error ? e.message : ui.operations.uploadFailed,
            );
          } finally {
            setBusy(false);
          }
        }}
      >
        {ui.operations.library}
      </button>}
      {images && (
        <div className="cover-options">
          {!images.length && <p>{ui.operations.libraryEmpty}</p>}
          {images.map((image, index) => (
            <div key={image.id}>
              <button
                type="button"
                key={image.id}
                aria-label={`${ui.operations.imageNumber} ${index + 1}`}
                onClick={() => {
                  onUpload(image.url);
                  setImages(undefined);
                }}
              >
                <Image
                  src={image.url}
                  alt=""
                  width={120}
                  height={90}
                  style={{ objectFit: "cover" }}
                />
              </button>
              <button
                type="button"
                className="small-button"
                disabled={busy}
                onClick={async () => {
                  if (!window.confirm(ui.operations.deleteImage)) return;
                  setBusy(true);
                  setError("");
                  try {
                    await staffRequest(`admin/media/${image.id}`, "DELETE");
                    setImages(images.filter((m) => m.id !== image.id));
                  } catch (e) {
                    setError(
                      e instanceof Error
                        ? e.message
                        : ui.operations.uploadFailed,
                    );
                  } finally {
                    setBusy(false);
                  }
                }}
              >
                {ui.admin.remove}
              </button>
            </div>
          ))}
        </div>
      )}
      {error && (
        <p role="alert" className="form-error">
          {error}
        </p>
      )}
    </div>
  );
}
