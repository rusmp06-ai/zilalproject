"use client";
import Image, { type ImageProps } from "next/image";
import { useEffect, useState } from "react";
import { isLocalPhoto, readPhoto } from "@/lib/photos";
import { ui } from "@/data/content/platform";
export function PhotoImage(props: ImageProps) {
  const source = typeof props.src === "string" ? props.src : "";
  const local = isLocalPhoto(source);
  const [photo, setPhoto] = useState<{ source: string; url?: string; error?: boolean }>();
  useEffect(() => {
    if (!local) return;
    let active = true;
    let url: string | undefined;
    readPhoto(source).then(blob => {
      if (!active) return;
      url = URL.createObjectURL(blob);
      setPhoto({ source, url });
    }).catch(() => { if (active) setPhoto({ source, error: true }); });
    return () => { active = false; if (url) URL.revokeObjectURL(url); };
  }, [source, local]);
  if (!local) return <Image {...props} />;
  if (photo?.source === source && photo.error)
    return <span className="photo-error" role="status">{ui.operations.photoMissing}</span>;
  if (photo?.source !== source || !photo.url) return null;
  return <Image {...props} src={photo.url} unoptimized />;
}
