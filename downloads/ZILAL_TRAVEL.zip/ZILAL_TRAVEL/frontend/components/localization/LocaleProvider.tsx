"use client";
import { createContext, useContext, type ReactNode } from "react";
import NextLink from "next/link";
import type { ComponentProps } from "react";
import { dictionaries } from "@/data/content";
import { ui as ru } from "@/data/content/platform";
import { enUI, fieldLabels } from "@/data/content/en-platform";
export type Locale = "ru" | "en";
const Context = createContext<Locale>("ru");
export function LocaleProvider({
  locale,
  children,
}: {
  locale: Locale;
  children: ReactNode;
}) {
  return <Context.Provider value={locale}>{children}</Context.Provider>;
}
export function localePath(path: string, locale: Locale) {
  if (
    !path.startsWith("/") ||
    path.startsWith("//") ||
    /^\/(?:admin|api|_next|images|login|reset-password)(?:\/|$)/.test(path)
  )
    return path;
  const clean = path.replace(/^\/en(?=\/|\?|$)/, "") || "/";
  return locale === "en" ? "/en" + (clean === "/" ? "" : clean) : clean;
}
export function useLocale() {
  const locale = useContext(Context);
  return {
    locale,
    t: dictionaries[locale],
    ui: locale === "en" ? enUI : ru,
    href: (path: string) => localePath(path, locale),
    label: (value: string) =>
      locale === "en" ? fieldLabels[value] || value : value,
  };
}
export function LocaleLink({
  href,
  ...props
}: ComponentProps<typeof NextLink>) {
  const { locale } = useLocale();
  return (
    <NextLink
      {...props}
      href={typeof href === "string" ? localePath(href, locale) : href}
    />
  );
}
