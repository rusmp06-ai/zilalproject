"use client";
import { useState, useRef, type FormEvent } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { usePlatform } from "@/components/providers/PlatformProvider";
import { configs } from "@/data/admin/config";
import { ui } from "@/data/content/platform";
import { useUnsavedChanges } from "@/hooks/useUnsavedChanges";
import { same } from "@/lib/storage";
import { imageChoices } from "@/lib/platform";
import { entities, type Entity, type Item } from "@/types/platform";
import { ImageUpload } from "@/components/server/ImageUpload";
import { InviteLink, LeadConversion } from "@/components/server/AccessTools";
import { PaymentLink } from "@/components/server/PaymentLink";
import { TranslationEditor } from "@/components/server/TranslationEditor";
import { writableSection } from "@/lib/access";
import { Landscape } from "@/components/ui/Primitives";
export function EntityEditor({ entity, id }: { entity: Entity; id: string }) {
  const { data, ready } = usePlatform();
  if (!ready) return <p>{ui.loading}</p>;
  const existing = data.collections[entity].find((r) => r.id === id);
  if (id !== "new" && !existing)
    return (
      <div className="admin-panel">
        <h1>{ui.tour.notFound}</h1>
        <Link className="button" href={`/admin/${entity}`}>
          {ui.back}
        </Link>
      </div>
    );
  return <Editor key={`${entity}:${id}`} entity={entity} initial={existing} />;
}
function Editor({ entity, initial }: { entity: Entity; initial?: Item }) {
  const { data, save, server, user } = usePlatform();
  const canWrite =
    !server ||
    (writableSection(user?.role, entity) &&
      !(
        entity === "employees" &&
        user?.role !== "super_admin" &&
        initial &&
        ["Супер-администратор", "Администратор"].includes(initial.fields.role)
      ));
  const config = configs[entity];
  const router = useRouter();
  const [item, setItem] = useState<Item>(
    () =>
      initial || {
        id: "",
        slug: "",
        title: "",
        description: "",
        status: config.statuses.includes("Черновик")
          ? "Черновик"
          : config.statuses[0],
        image: "/images/lake.svg",
        fields: Object.fromEntries(
          config.fields.map((field) => [
            field.key,
            server && entity === "employees" && field.key === "role"
              ? "Менеджер"
              : field.options?.[0] || "",
          ]),
        ),
      },
  );
  const baseline = useRef(item);
  const dirty = !same(item, baseline.current);
  const allowNavigation = useUnsavedChanges(dirty);
  const conflict = !!initial && !same(initial, baseline.current);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");
  const update = (key: keyof Omit<Item, "fields">, value: string) =>
    setItem((previous) => ({ ...previous, [key]: value }));
  const field = (key: string, value: string) =>
    setItem((previous) => ({
      ...previous,
      fields: { ...previous.fields, [key]: value },
    }));
  const related = initial
    ? entities.flatMap((e) =>
        data.collections[e]
          .filter((row) =>
            configs[e].fields.some(
              (f) => f.relation === entity && row.fields[f.key] === initial.id,
            ),
          )
          .map((row) => ({ entity: e, row })),
      )
    : [];
  const submit = async (event: FormEvent) => {
    event.preventDefault();
    if (!canWrite || !item.title.trim()) {
      setError(ui.admin.validation);
      return;
    }
    const id = item.id || `${entity}-${crypto.randomUUID()}`;
    const slug = (item.slug.trim() || id).toLowerCase();
    if (!/^[a-z0-9]+(?:-[a-z0-9]+)*$/.test(slug)) {
      setError(ui.admin.invalidSlug);
      return;
    }
    if (
      data.collections[entity].some((row) => row.slug === slug && row.id !== id)
    ) {
      setError(ui.admin.duplicate);
      return;
    }
    const normalized = {
      ...item,
      id,
      slug,
      title: item.title.trim(),
      description: item.description.trim(),
    };
    if (saving) return;
    setSaving(true);
    setError("");
    const result = await save(
      entity,
      normalized,
      initial ? baseline.current : undefined,
    );
    setSaving(false);
    if (!result.ok) {
      setError(
        result.kind === "storage" || result.kind === "corrupt"
          ? ui.admin.saveFailed
          : result.error,
      );
      return;
    }
    allowNavigation();
    router.push(`/admin/${entity}`);
  };
  return (
    <>
      <div className="admin-page-heading">
        <div>
          <Link href={`/admin/${entity}`} className="text-link">
            ← {config.label}
          </Link>
          <h1>
            {initial ? ui.admin.edit : ui.admin.create} · {config.singular}
          </h1>
          <p>{config.description}</p>
        </div>
        {config.publicPath &&
          initial?.status === "Опубликован" &&
          entity !== "gallery" && (
            <Link
              className="small-button"
              href={`${config.publicPath}/${initial.slug}`}
            >
              {ui.admin.preview}
            </Link>
          )}
      </div>
      {!canWrite && <p className="demo-note">{ui.operations.readOnly}</p>}
      {dirty && (
        <p className="draft-notice" role="status">
          {ui.admin.dirty}
        </p>
      )}
      {conflict && (
        <p className="form-error" role="alert">
          {ui.admin.conflict}
        </p>
      )}
      <form className="entity-form" onSubmit={submit}>
        <div className="admin-panel">
          <div className="editor-fields">
            <label className="field-wide">
              {ui.admin.titleField}
              <input
                required
                disabled={!canWrite}
                maxLength={200}
                value={item.title}
                onChange={(e) => update("title", e.target.value)}
              />
            </label>
            {config.publicPath && (
              <label>
                {ui.admin.slug}
                <input
                  pattern="[a-z0-9]+(-[a-z0-9]+)*"
                  maxLength={100}
                  required
                  aria-label={ui.admin.slug}
                  readOnly={!!initial}
                  value={item.slug}
                  onChange={(e) => update("slug", e.target.value)}
                />
                {initial && <small>{ui.admin.readonlySlug}</small>}
              </label>
            )}
            <label>
              {ui.admin.status}
              <select
                disabled={!canWrite}
                aria-label={ui.admin.status}
                value={item.status}
                onChange={(e) => update("status", e.target.value)}
              >
                {config.statuses.map((v) => (
                  <option key={v}>{v}</option>
                ))}
              </select>
            </label>
            {!initial && config.statuses.includes("Черновик") && (
              <p className="demo-note field-wide">{ui.admin.draftHint}</p>
            )}
            <label className="field-wide">
              {ui.admin.descriptionField}
              <textarea
                disabled={!canWrite}
                aria-label={ui.admin.descriptionField}
                rows={3}
                maxLength={3000}
                value={item.description}
                onChange={(e) => update("description", e.target.value)}
              />
            </label>
            {config.fields.map((f) => (
              <label
                className={f.type === "textarea" ? "field-wide" : ""}
                key={f.key}
              >
                {f.label}
                {f.required ? " *" : ""}
                {f.type === "textarea" ? (
                  <textarea
                    disabled={!canWrite}
                    aria-label={f.label}
                    rows={f.key === "body" || f.key === "itinerary" ? 7 : 3}
                    maxLength={20000}
                    value={item.fields[f.key] || ""}
                    onChange={(e) => field(f.key, e.target.value)}
                  />
                ) : f.type === "select" ? (
                  <select
                    aria-label={f.label}
                    required={f.required}
                    disabled={
                      !canWrite ||
                      (server &&
                        entity === "bookings" &&
                        f.key === "paymentStatus")
                    }
                    value={item.fields[f.key] || ""}
                    onChange={(e) => field(f.key, e.target.value)}
                  >
                    {f.relation ? (
                      <>
                        <option value="">{ui.admin.none}</option>
                        {data.collections[f.relation].map((row) => (
                          <option key={row.id} value={row.id}>
                            {row.title}
                          </option>
                        ))}
                      </>
                    ) : (
                      f.options
                        ?.filter(
                          (v) =>
                            !(
                              server &&
                              entity === "employees" &&
                              f.key === "role" &&
                              user?.role !== "super_admin" &&
                              v !== item.fields.role &&
                              ["Супер-администратор", "Администратор"].includes(
                                v,
                              )
                            ),
                        )
                        .map((v) => <option key={v}>{v}</option>)
                    )}
                  </select>
                ) : (
                  <input
                    aria-label={f.required ? `${f.label} *` : f.label}
                    type={f.type || "text"}
                    required={f.required}
                    disabled={
                      !canWrite ||
                      (server &&
                        entity === "bookings" &&
                        f.key === "paymentStatus")
                    }
                    min={
                      f.type === "date" && f.key === "end"
                        ? item.fields.start
                        : f.min
                    }
                    max={f.max}
                    step={f.type === "number" ? (f.step ?? "any") : undefined}
                    maxLength={f.type === "text" || !f.type ? 500 : undefined}
                    value={item.fields[f.key] || ""}
                    onChange={(e) => field(f.key, e.target.value)}
                  />
                )}
              </label>
            ))}
          </div>
        </div>
        {(config.publicPath ||
          entity === "reviews" ||
          entity === "gallery") && (
          <aside className="admin-panel cover-editor">
            <h2>{ui.admin.image}</h2>
            <Landscape src={item.image} alt={item.title} />
            <div className="cover-options">
              {imageChoices.map((image, index) => (
                <button
                  type="button"
                  key={image}
                  aria-pressed={item.image === image}
                  onClick={() => update("image", image)}
                >
                  {ui.admin.placeholderOptions[index]}
                </button>
              ))}
            </div>
            {server && <ImageUpload onUpload={(url) => update("image", url)} />}
            <p className="demo-note">{ui.illustration}</p>
          </aside>
        )}
        <div className="editor-actions">
          {error && !(conflict && error === ui.admin.conflict) && (
            <p role="alert" className="form-error">
              {error}
            </p>
          )}
          <button
            type="submit"
            className="button"
            disabled={saving || conflict || !canWrite}
          >
            {saving ? ui.admin.saving : ui.admin.save}
          </button>
          <Link className="small-button" href={`/admin/${entity}`}>
            {ui.admin.cancel}
          </Link>
        </div>
      </form>
      {server &&
        entity === "bookings" &&
        initial &&
        ["admin", "super_admin"].includes(user?.role || "") && (
          <PaymentLink id={initial.id} />
        )}
      {server && initial && entity === "leads" && !dirty && (
        <LeadConversion id={initial.id} version={initial.version || 0} />
      )}
      {server && canWrite && initial && entity === "employees" && (
        <InviteLink id={initial.id} />
      )}
      {server &&
        initial &&
        [
          "tours",
          "destinations",
          "experiences",
          "journal",
          "gallery",
          "reviews",
        ].includes(entity) && (
          <TranslationEditor entity={entity} item={initial} />
        )}
      {related.length > 0 && (
        <section className="admin-panel">
          <h2>{ui.admin.related}</h2>
          <div className="related-records">
            {related.map(({ entity: e, row }) => (
              <Link key={e + row.id} href={`/admin/${e}/${row.id}`}>
                <span>{configs[e].label}</span>
                <strong>{row.title}</strong>
                <span>{row.status}</span>
              </Link>
            ))}
          </div>
        </section>
      )}
    </>
  );
}
