import { ContentDetail } from "@/components/public/ContentDetail";
import { itemMetadata } from "@/services/seo";
import { publicItem } from "@/services/server";
export async function generateMetadata({
  params,
}: {
  params: Promise<{ slug: string }>;
}) {
  const { slug } = await params;
  const item = await publicItem("journal", slug);
  return itemMetadata(item, "journal", slug);
}
export default async function Page({
  params,
}: {
  params: Promise<{ slug: string }>;
}) {
  const { slug } = await params;
  await publicItem("journal", slug);
  return <ContentDetail entity="journal" slug={slug} />;
}
