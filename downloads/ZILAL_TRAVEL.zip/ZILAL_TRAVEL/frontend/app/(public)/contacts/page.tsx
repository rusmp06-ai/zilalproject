import { Contacts } from "@/components/public/Contacts";
import { requestLocale } from "@/services/server";
export async function generateMetadata() {
  return {
    title: `${(await requestLocale()) === "en" ? "Contact" : "Контакты"} — ZILAL TRAVEL`,
  };
}
export default function Page() {
  return <Contacts />;
}
