import { Catalog } from "@/components/public/Catalog";
import { requestLocale } from "@/services/server";
export async function generateMetadata() {
  return {
    title: `${(await requestLocale()) === "en" ? "Experiences" : "Впечатления"} — ZILAL TRAVEL`,
  };
}
export default function Page() {
  return <Catalog entity="experiences" />;
}
