import { ContentDetail } from "@/components/public/ContentDetail";
import { itemMetadata } from "@/services/seo";
import { publicItem } from "@/services/server";
export async function generateMetadata({
  params,
}: {
  params: Promise<{ slug: string }>;
}) {
  const { slug } = await params;
  const item = await publicItem("experiences", slug);
  return itemMetadata(item, "experiences", slug);
}
export default async function Page({
  params,
}: {
  params: Promise<{ slug: string }>;
}) {
  const { slug } = await params;
  await publicItem("experiences", slug);
  return <ContentDetail entity="experiences" slug={slug} />;
}
