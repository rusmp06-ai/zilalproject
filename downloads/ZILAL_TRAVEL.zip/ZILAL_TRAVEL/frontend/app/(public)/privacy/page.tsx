import { privacy as privacyRu, privacyEn } from "@/data/content/privacy";
import { publicData, requestLocale } from "@/services/server";
export async function generateMetadata() {
  return {
    title: `${(await requestLocale()) === "en" ? "How we use your data" : "Использование данных"} — ZILAL TRAVEL`,
  };
}
export default async function Page() {
  const { settings } = await publicData();
  const privacy = (await requestLocale()) === "en" ? privacyEn : privacyRu;
  return (
    <article className="container public-page">
      <h1>{privacy.title}</h1>
      <p>{privacy.intro}</p>
      {privacy.sections.map((section) => (
        <section key={section.title}>
          <h2>{section.title}</h2>
          <p>{section.text}</p>
        </section>
      ))}
      {settings.email && (
        <p>
          <a href={`mailto:${settings.email}`}>{settings.email}</a>
        </p>
      )}
      <p className="demo-note">{privacy.beforeLaunch}</p>
    </article>
  );
}
