import { PlanForm } from "@/components/public/PlanForm";
import { requestLocale } from "@/services/server";
export async function generateMetadata() {
  return {
    title: `${(await requestLocale()) === "en" ? "Plan your journey" : "Спланировать путешествие"} — ZILAL TRAVEL`,
  };
}
export default function Page() {
  return <PlanForm />;
}
