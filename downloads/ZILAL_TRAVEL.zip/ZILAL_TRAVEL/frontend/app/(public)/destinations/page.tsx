import { Catalog } from "@/components/public/Catalog";
import { requestLocale } from "@/services/server";
export async function generateMetadata() {
  return {
    title: `${(await requestLocale()) === "en" ? "Destinations" : "Направления"} — ZILAL TRAVEL`,
  };
}
export default function Page() {
  return <Catalog entity="destinations" />;
}
