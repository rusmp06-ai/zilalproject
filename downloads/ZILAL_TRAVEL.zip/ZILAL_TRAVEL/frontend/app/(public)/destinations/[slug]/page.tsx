import { ContentDetail } from "@/components/public/ContentDetail";
import { itemMetadata } from "@/services/seo";
import { publicItem } from "@/services/server";
export async function generateMetadata({
  params,
}: {
  params: Promise<{ slug: string }>;
}) {
  const { slug } = await params;
  const item = await publicItem("destinations", slug);
  return itemMetadata(item, "destinations", slug);
}
export default async function Page({
  params,
}: {
  params: Promise<{ slug: string }>;
}) {
  const { slug } = await params;
  await publicItem("destinations", slug);
  return <ContentDetail entity="destinations" slug={slug} />;
}
