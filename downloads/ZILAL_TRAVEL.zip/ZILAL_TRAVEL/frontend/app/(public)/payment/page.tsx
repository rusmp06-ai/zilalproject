import { Payment } from "@/components/public/Payment";
import { requestLocale } from "@/services/server";
export async function generateMetadata() {
  return {
    title: `${(await requestLocale()) === "en" ? "Payment" : "Оплата"} — ZILAL TRAVEL`,
    robots: { index: false, follow: false },
    referrer: "no-referrer" as const,
  };
}
export default function Page() {
  return <Payment />;
}
