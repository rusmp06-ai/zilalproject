import { ContentDetail } from "@/components/public/ContentDetail";
import { itemMetadata } from "@/services/seo";
import { publicItem } from "@/services/server";
export async function generateMetadata({
  params,
}: {
  params: Promise<{ slug: string }>;
}) {
  const { slug } = await params;
  const item = await publicItem("tours", slug);
  return itemMetadata(item, "tours", slug);
}
export default async function Page({
  params,
}: {
  params: Promise<{ slug: string }>;
}) {
  const { slug } = await params;
  await publicItem("tours", slug);
  return <ContentDetail entity="tours" slug={slug} />;
}
