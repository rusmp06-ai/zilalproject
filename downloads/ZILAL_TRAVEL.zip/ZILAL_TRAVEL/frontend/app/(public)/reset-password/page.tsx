import { notFound } from "next/navigation";
import { serverMode } from "@/services/server";
import { PasswordForm } from "@/components/server/AccessTools";
export default function Page() {
  if (!serverMode()) notFound();
  return <PasswordForm />;
}

export const metadata = {
  robots: { index: false, follow: false },
  referrer: "no-referrer",
};
