import { About } from "@/components/public/About";
import { requestLocale } from "@/services/server";
export async function generateMetadata() {
  return {
    title: `${(await requestLocale()) === "en" ? "About us" : "О нас"} — ZILAL TRAVEL`,
  };
}
export default function Page() {
  return <About />;
}
