import { indexingEnabled, siteURL } from "@/services/seo";
import type { Metadata } from "next";
import { headers } from "next/headers";
import "@fontsource/cormorant-garamond/cyrillic-400.css";
import "@fontsource/cormorant-garamond/latin-400.css";
import "@fontsource/cormorant-garamond/cyrillic-500.css";
import "@fontsource/cormorant-garamond/latin-500.css";
import "@fontsource/manrope/cyrillic-400.css";
import "@fontsource/manrope/latin-400.css";
import "@fontsource/manrope/cyrillic-600.css";
import "@fontsource/manrope/latin-600.css";
import "./globals.css";
import { PlatformProvider } from "@/components/providers/PlatformProvider";
import { publicData, serverMode, requestLocale } from "@/services/server";
import { LocaleProvider } from "@/components/localization/LocaleProvider";
import { dictionaries } from "@/data/content";
export async function generateMetadata(): Promise<Metadata> {
  const data = await publicData();
  const t = dictionaries[await requestLocale()];
  const path = (await headers()).get("x-zilal-public-path") || "/";
  const plain = path.replace(/^\/en(?=\/|$)/, "") || "/";
  const publicStatic = [
    "/",
    "/about",
    "/contacts",
    "/tours",
    "/destinations",
    "/experiences",
    "/journal",
    "/gallery",
    "/plan",
    "/privacy",
  ].includes(plain);
  const alternates = publicStatic
    ? {
        canonical: path,
        languages: { ru: plain, en: "/en" + (plain === "/" ? "" : plain) },
      }
    : undefined;
  return {
    metadataBase: siteURL(),
    alternates,
    title: `${data.settings.company} — ${t.brandCaption}`,
    description: data.settings.heroDescription,
    robots: { index: indexingEnabled(), follow: indexingEnabled() },
  };
}
export default async function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const initial = serverMode() ? await publicData() : undefined;
  const locale = await requestLocale();
  return (
    <html lang={locale}>
      <body>
        <LocaleProvider locale={locale} key={locale}>
          <PlatformProvider initial={initial} server={serverMode()}>
            {children}
          </PlatformProvider>
        </LocaleProvider>
      </body>
    </html>
  );
}
