import type { MetadataRoute } from "next";
import { indexingEnabled, siteURL } from "@/services/seo";
import { publicData } from "@/services/server";
export default async function sitemap(): Promise<MetadataRoute.Sitemap> {
  if (!indexingEnabled()) return [];
  const data = await publicData("ru");
  const paths = [
    "/",
    "/about",
    "/contacts",
    "/tours",
    "/destinations",
    "/experiences",
    "/journal",
    "/gallery",
    "/privacy",
  ];
  for (const entity of [
    "tours",
    "destinations",
    "experiences",
    "journal",
  ] as const) {
    for (const row of data.collections[entity])
      if (row.status === "Опубликован")
        paths.push(`/${entity}/${encodeURIComponent(row.slug)}`);
  }
  const english = await publicData("en");
  const enPaths = paths
    .filter((path) => path.split("/").length < 3)
    .map((path) => "/en" + (path === "/" ? "" : path));
  for (const entity of [
    "tours",
    "destinations",
    "experiences",
    "journal",
  ] as const) {
    for (const row of english.collections[entity])
      if (row.status === "Опубликован")
        enPaths.push(`/en/${entity}/${encodeURIComponent(row.slug)}`);
  }
  return [...paths, ...enPaths].map((path) => ({
    url: new URL(path, siteURL()).href,
  }));
}
