import type { MetadataRoute } from "next";
import { indexingEnabled, siteURL } from "@/services/seo";
export default function robots(): MetadataRoute.Robots {
  return indexingEnabled()
    ? {
        rules: {
          userAgent: "*",
          allow: "/",
          disallow: ["/admin", "/api/", "/login", "/reset-password", "/plan"],
        },
        sitemap: new URL("/sitemap.xml", siteURL()).href,
      }
    : { rules: { userAgent: "*", disallow: "/" } };
}
