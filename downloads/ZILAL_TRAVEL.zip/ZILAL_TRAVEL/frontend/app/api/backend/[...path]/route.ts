import { NextRequest } from "next/server";
import { backendURL, serverMode } from "@/services/server";
const crm = "(?:leads|customers|bookings|partners|payments)";
const entities = "(?:tours|destinations|experiences|journal|gallery|reviews)";
function permitted(path: string, method: string) {
  if (method === "GET")
    return (
      /^(auth\/me|public\/platform|admin\/platform|admin\/media|admin\/operations|admin\/site-translation\/en)$/.test(
        path,
      ) ||
      new RegExp(
        `^admin/translations/${entities}/[a-zA-Z0-9_-]+/(ru|en)$`,
      ).test(path)
    );
  if (method === "POST")
    return (
      /^(auth\/(login|logout|reset-password|change-password))$/.test(path) ||
      new RegExp(`^admin/content/${entities}$`).test(path) ||
      new RegExp(`^admin/crm/${crm}$`).test(path) ||
      /^admin\/employees(?:\/[a-zA-Z0-9_-]+\/invite)?$/.test(path) ||
      /^admin\/leads\/[a-zA-Z0-9_-]+\/convert$/.test(path) ||
      path === "public/leads" ||
      path === "public/payment-info" ||
      /^admin\/bookings\/[a-zA-Z0-9_-]+\/payment-link$/.test(path) ||
      path === "admin/media"
    );
  if (method === "PUT")
    return (
      path === "admin/settings" ||
      path === "admin/site-translation/en" ||
      new RegExp(
        `^admin/translations/${entities}/[a-zA-Z0-9_-]+/(ru|en)$`,
      ).test(path) ||
      new RegExp(
        `^admin/(?:content/${entities}|crm/${crm}|employees)/[a-zA-Z0-9_-]+$`,
      ).test(path)
    );
  if (method === "DELETE")
    return (
      /^admin\/media\/[a-f0-9-]{36}$/.test(path) ||
      new RegExp(
        `^admin/(?:content/${entities}|crm/${crm}|employees)/[a-zA-Z0-9_-]+$`,
      ).test(path)
    );
  return false;
}
async function handle(
  request: NextRequest,
  { params }: { params: Promise<{ path: string[] }> },
) {
  if (!serverMode())
    return Response.json(
      { detail: "Серверный режим не включён" },
      { status: 404 },
    );
  const path = (await params).path.join("/");
  if (!permitted(path, request.method))
    return Response.json({ detail: "Маршрут не найден" }, { status: 404 });
  if (
    request.method !== "GET" &&
    request.headers.get("origin") !== process.env.SITE_ORIGIN
  )
    return Response.json(
      { detail: "Недопустимый источник запроса" },
      { status: 403 },
    );
  const headers: Record<string, string> = {
    "Content-Type":
      path === "admin/media" ? "application/octet-stream" : "application/json",
  };
  const token = request.cookies.get("zilal_session")?.value;
  if (token) headers.Cookie = `zilal_session=${token}`;
  for (const name of ["origin", "x-csrf-token"]) {
    const value = request.headers.get(name);
    if (value) headers[name] = value;
  }
  try {
    const limit = path === "admin/media" ? 8 * 1024 * 1024 : 262144;
    const chunks: Uint8Array[] = [];
    let size = 0;
    if (["POST", "PUT"].includes(request.method) && request.body) {
      const reader = request.body.getReader();
      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        size += value.byteLength;
        if (size > limit) {
          await reader.cancel();
          return Response.json(
            { detail: "Запрос слишком большой" },
            { status: 413 },
          );
        }
        chunks.push(value);
      }
    }
    const body = size ? new Uint8Array(size) : undefined;
    let offset = 0;
    for (const chunk of chunks) {
      body!.set(chunk, offset);
      offset += chunk.byteLength;
    }
    const url = `${backendURL()}/api/v1/${path}`;
    const version = request.nextUrl.searchParams.get("version");
    const locale = request.nextUrl.searchParams.get("locale");
    const query =
      request.method === "GET" && path === "public/platform"
        ? `?locale=${locale === "en" ? "en" : "ru"}`
        : request.method === "DELETE" && version
          ? `?version=${encodeURIComponent(version)}`
          : "";
    const upstream = await fetch(url + query, {
      method: request.method,
      headers,
      body,
      cache: "no-store",
      redirect: "error",
      signal: AbortSignal.timeout(60000),
    });
    const response = new Response(await upstream.text(), {
      status: upstream.status,
      headers: {
        "Content-Type": "application/json",
        "Cache-Control": "no-store",
        "X-Content-Type-Options": "nosniff",
      },
    });
    for (const cookie of upstream.headers.getSetCookie())
      response.headers.append("Set-Cookie", cookie);
    return response;
  } catch {
    return Response.json(
      {
        detail:
          "Сервер пока недоступен. Данные не сохранены; попробуйте ещё раз.",
      },
      { status: 503 },
    );
  }
}
export { handle as GET, handle as POST, handle as PUT, handle as DELETE };
