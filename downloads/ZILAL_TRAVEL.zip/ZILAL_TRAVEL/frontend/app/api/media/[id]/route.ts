import { backendURL, serverMode } from "@/services/server";
export async function GET(
  _request: Request,
  { params }: { params: Promise<{ id: string }> },
) {
  const { id } = await params;
  if (!serverMode() || !/^[a-f0-9-]{36}$/.test(id))
    return new Response(null, { status: 404 });
  try {
    const r = await fetch(`${backendURL()}/api/v1/public/media/${id}`, {
      cache: "no-store",
      signal: AbortSignal.timeout(60000),
      redirect: "error",
    });
    if (!r.ok)
      return new Response(null, { status: r.status === 404 ? 404 : 503 });
    return new Response(r.body, {
      headers: {
        "Content-Type": "image/webp",
        "Cache-Control": "public, max-age=31536000, immutable",
        "X-Content-Type-Options": "nosniff",
      },
    });
  } catch {
    return new Response(null, { status: 503 });
  }
}
