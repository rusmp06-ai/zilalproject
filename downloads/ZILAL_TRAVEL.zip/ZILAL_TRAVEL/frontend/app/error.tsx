"use client";
import {
  useLocale,
  LocaleLink as Link,
} from "@/components/localization/LocaleProvider";
export default function ErrorPage({ reset }: { reset: () => void }) {
  const { ui } = useLocale();
  return (
    <main className="container public-page">
      <h1>{ui.backend.unavailable}</h1>
      <p>{ui.backend.retryHint}</p>
      <button className="button" onClick={reset}>
        {ui.backend.retry}
      </button>
    </main>
  );
}
