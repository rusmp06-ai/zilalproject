"use client";

import {
  useLocale,
  LocaleLink as Link,
} from "@/components/localization/LocaleProvider";
export default function NotFound() {
  const { ui } = useLocale();
  return (
    <main className="container public-page">
      <p className="eyebrow">404</p>
      <h1>{ui.tour.notFound}</h1>
      <p>{ui.tour.unavailable}</p>
      <Link className="button" href="/">
        {ui.home}
      </Link>
    </main>
  );
}
