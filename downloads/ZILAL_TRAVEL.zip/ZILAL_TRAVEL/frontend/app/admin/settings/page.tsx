import { requireAdmin, serverMode } from "@/services/server";
import { notFound } from "next/navigation";
import { Settings } from "@/components/admin/Settings";
export default async function Page() {
  const auth = await requireAdmin();
  if (serverMode() && !["super_admin", "admin"].includes(auth?.user.role))
    notFound();
  return <Settings />;
}
