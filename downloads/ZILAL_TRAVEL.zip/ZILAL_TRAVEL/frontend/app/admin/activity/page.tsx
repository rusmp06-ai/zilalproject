import { requireContentSection } from "@/services/server";
import { Activity } from "@/components/admin/Activity";
export default async function Page() {
  await requireContentSection("activity");
  return <Activity />;
}
