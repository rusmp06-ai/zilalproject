import { requireContentSection } from "@/services/server";
import { Dashboard } from "@/components/admin/Dashboard";
export default async function Page() {
  await requireContentSection("reports");
  return <Dashboard reports />;
}
