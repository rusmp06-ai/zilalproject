import { requireAdmin, serverMode } from "@/services/server";
import { notFound } from "next/navigation";
import { PasswordForm } from "@/components/server/AccessTools";
export default async function Page() {
  await requireAdmin();
  if (!serverMode()) notFound();
  return <PasswordForm change />;
}
