import { requireContentSection } from "@/services/server";
import { notFound } from "next/navigation";
import { EntityList } from "@/components/admin/EntityList";
import { entities, type Entity } from "@/types/platform";
export default async function Page({
  params,
}: {
  params: Promise<{ section: string }>;
}) {
  const { section } = await params;
  await requireContentSection(section);
  if (!entities.includes(section as Entity)) notFound();
  return <EntityList key={section} entity={section as Entity} />;
}
