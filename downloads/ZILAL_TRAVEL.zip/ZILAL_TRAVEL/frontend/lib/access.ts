const content = [
  "tours",
  "destinations",
  "experiences",
  "journal",
  "gallery",
  "reviews",
];
export function allowedSection(role: string | undefined, section: string) {
  if (section === "account") return true;
  if (["super_admin", "admin"].includes(role || ""))
    return [
      ...content,
      "leads",
      "customers",
      "bookings",
      "partners",
      "payments",
      "employees",
      "settings",
      "reports",
      "activity",
    ].includes(section);
  if (role === "content_manager")
    return [...content, "activity"].includes(section);
  if (role === "manager")
    return ["leads", "customers", "bookings", "partners", "reports"].includes(
      section,
    );
  if (role === "operator")
    return ["bookings", "partners", "customers"].includes(section);
  return false;
}
export function writableSection(role: string | undefined, section: string) {
  if (!allowedSection(role, section)) return false;
  return !(
    (role === "manager" && section === "partners") ||
    (role === "operator" && section === "customers")
  );
}
export function entityEndpoint(entity: string) {
  return entity === "employees"
    ? "admin/employees"
    : `admin/${content.includes(entity) ? "content" : "crm"}/${entity}`;
}
