import { ui } from "@/data/content/platform";
// Compact self-contained demo photos also travel with the JSON backup.
export async function compressPhoto(file: File): Promise<string> {
  if (!['image/jpeg', 'image/png', 'image/webp'].includes(file.type) || file.size > 8 * 1024 * 1024)
    throw Error(ui.operations.photoInvalid);
  let bitmap: ImageBitmap;
  try { bitmap = await createImageBitmap(file); }
  catch { throw Error(ui.operations.photoInvalid); }
  try {
    if (bitmap.width * bitmap.height > 25_000_000) throw Error(ui.operations.photoInvalid);
    const canvas = document.createElement('canvas');
    let size = 1400;
    for (let attempt = 0; attempt < 5; attempt++) {
      const scale = Math.min(1, size / Math.max(bitmap.width, bitmap.height));
      canvas.width = Math.max(1, Math.round(bitmap.width * scale));
      canvas.height = Math.max(1, Math.round(bitmap.height * scale));
      const context = canvas.getContext('2d');
      if (!context) throw Error(ui.operations.photoInvalid);
      context.drawImage(bitmap, 0, 0, canvas.width, canvas.height);
      const result = canvas.toDataURL('image/webp', 0.78);
      if (result.startsWith('data:image/webp;base64,') && result.length <= 180000) return result;
      size = Math.round(size * 0.75);
    }
    throw Error(ui.operations.photoInvalid);
  } finally { bitmap.close(); }
}
