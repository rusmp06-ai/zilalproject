import { ui } from "@/data/content/platform";
import { entities, type PlatformData } from "@/types/platform";
export const isLocalPhoto = (src: string) => /^local-photo:[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/.test(src);
const raster = /^data:image\/(?:webp|jpeg|png);base64,[A-Za-z0-9+/]+={0,2}$/;
export const isPhotoData = (src: string) => src.length <= 12_000_000 && raster.test(src);
function openPhotos(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open("zilal-photos-v1", 1);
    request.onupgradeneeded = () => request.result.createObjectStore("photos");
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(Error(ui.operations.photoStorageError));
  });
}
async function writePhoto(blob: Blob): Promise<string> {
  const db = await openPhotos();
  const id = `local-photo:${crypto.randomUUID()}`;
  try {
    await new Promise<void>((resolve, reject) => {
      const transaction = db.transaction("photos", "readwrite");
      transaction.objectStore("photos").add(blob, id);
      transaction.oncomplete = () => resolve();
      transaction.onabort = transaction.onerror = () => reject(Error(ui.operations.photoStorageError));
    });
    return id;
  } finally { db.close(); }
}
export async function readPhoto(id: string): Promise<Blob> {
  if (!isLocalPhoto(id)) throw Error(ui.operations.photoMissing);
  const db = await openPhotos();
  try {
    return await new Promise<Blob>((resolve, reject) => {
      const request = db.transaction("photos").objectStore("photos").get(id);
      request.onsuccess = () => request.result instanceof Blob ? resolve(request.result) : reject(Error(ui.operations.photoMissing));
      request.onerror = () => reject(Error(ui.operations.photoStorageError));
    });
  } finally { db.close(); }
}
async function validatePhoto(blob: Blob) {
  if (!['image/jpeg', 'image/png', 'image/webp'].includes(blob.type) || blob.size > 8 * 1024 * 1024)
    throw Error(ui.operations.photoInvalid);
  const signature = new Uint8Array(await blob.slice(0, 12).arrayBuffer());
  const actualRaster =
    (blob.type === "image/jpeg" && signature[0] === 0xff && signature[1] === 0xd8 && signature[2] === 0xff) ||
    (blob.type === "image/png" && [137,80,78,71,13,10,26,10].every((byte, index) => signature[index] === byte)) ||
    (blob.type === "image/webp" && String.fromCharCode(...signature.slice(0,4)) === "RIFF" && String.fromCharCode(...signature.slice(8,12)) === "WEBP");
  if (!actualRaster) throw Error(ui.operations.photoInvalid);
  let bitmap: ImageBitmap;
  try { bitmap = await createImageBitmap(blob); }
  catch { throw Error(ui.operations.photoInvalid); }
  try {
    if (bitmap.width * bitmap.height > 25_000_000) throw Error(ui.operations.photoInvalid);
  } finally { bitmap.close(); }
}
// Store the original bytes: no resizing, recompression or localStorage quota pressure.
export async function savePhoto(file: File): Promise<string> {
  await validatePhoto(file);
  return writePhoto(file);
}
function photoData(blob: Blob): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result as string);
    reader.onerror = () => reject(Error(ui.operations.photoStorageError));
    reader.readAsDataURL(blob);
  });
}
async function mapPhotos(data: PlatformData, transform: (src: string) => Promise<string>) {
  const copy = structuredClone(data);
  const cache = new Map<string, Promise<string>>();
  const convert = (src: string) => {
    if (!cache.has(src)) cache.set(src, transform(src));
    return cache.get(src)!;
  };
  copy.settings.heroImage = await convert(copy.settings.heroImage);
  for (const entity of entities)
    for (const item of copy.collections[entity]) item.image = await convert(item.image);
  return copy;
}
export const exportPhotos = (data: PlatformData) => mapPhotos(data, async src =>
  isLocalPhoto(src) ? photoData(await readPhoto(src)) : src);
export const importPhotos = (data: PlatformData) => mapPhotos(data, async src => {
  if (isLocalPhoto(src)) { await readPhoto(src); return src; }
  if (!isPhotoData(src)) return src;
  const comma = src.indexOf(',');
  const bytes = Uint8Array.from(atob(src.slice(comma + 1)), c => c.charCodeAt(0));
  const blob = new Blob([bytes], { type: src.slice(5, src.indexOf(';')) });
  await validatePhoto(blob);
  return writePhoto(blob);
});
