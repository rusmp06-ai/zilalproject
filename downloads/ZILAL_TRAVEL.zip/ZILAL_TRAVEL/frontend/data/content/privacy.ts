export const privacy = {
  title: "Как мы используем данные",
  intro:
    "Форма путешествия передаёт ваши пожелания и контакты команде для подготовки предложения. Отправка заявки не подтверждает бронирование и не списывает деньги.",
  sections: [
    {
      title: "Что сохраняет форма",
      text: "Имя, email, телефон при его указании, страну проживания, даты или гибкость дат, размер группы, интересы, предпочтения по проживанию, бюджет и пожелания. Вместе с заявкой сохраняются время согласия и номер обращения. Не указывайте в свободном тексте паспортные, платёжные или медицинские сведения.",
    },
    {
      title: "Кто получает доступ",
      text: "Данные хранятся на сервере и доступны сотрудникам с соответствующими рабочими ролями. Публичный сайт не показывает заявки, контакты клиентов или бронирования. Сервисные ограничения частоты запросов используют хеш адреса клиента API.",
    },
    {
      title: "Cookies и фотографии",
      text: "Рабочий кабинет использует необходимый cookie защищённой сессии сотрудника. Загрузка фотографий предназначена для публичных материалов сайта: загруженные изображения доступны по ссылке, преобразуются в WebP и очищаются от метаданных камеры.",
    },
    {
      title: "Уточнение и удаление",
      text: "Для исправления данных или запроса на удаление обратитесь к команде через контакты сайта и укажите номер обращения. Финансовые записи и резервные копии могут требовать отдельного срока хранения.",
    },
  ],
  beforeLaunch:
    "Перед публичным запуском владелец должен подтвердить реквизиты оператора, контакт для запросов, сроки хранения и условия привлечения поставщиков инфраструктуры. Этот проект пока не опубликован для приёма реальных обращений.",
};

export const privacyEn = {
  title: "How we use your data",
  intro:
    "The travel form sends your wishes and contact details to our team to prepare a proposal. An enquiry does not confirm a booking or charge your account.",
  sections: [
    {
      title: "What the form saves",
      text: "Your name, email, optional phone number, country of residence, travel dates or flexibility, group size, interests, accommodation preferences, budget and wishes. We also save your consent time and enquiry reference. Please do not include passport, payment or medical information in free text.",
    },
    {
      title: "Who can access your details",
      text: "Details are stored on the server and available to staff with the appropriate work roles. The public site does not display enquiries, client contacts or bookings. Request limits use a hash of the API client's address.",
    },
    {
      title: "Cookies and photographs",
      text: "The staff workspace uses a necessary secure session cookie. Uploaded photographs are intended for public site content: images are accessible by link, converted to WebP and stripped of camera metadata.",
    },
    {
      title: "Corrections and deletion",
      text: "For a correction or deletion request, contact the team through this site's contact details and provide your enquiry reference. Financial records and backups may require separate retention periods.",
    },
  ],
  beforeLaunch:
    "Before public launch, the owner must confirm the operator's details, enquiry contact, retention periods and infrastructure suppliers. This project has not yet been published to accept real enquiries.",
};
