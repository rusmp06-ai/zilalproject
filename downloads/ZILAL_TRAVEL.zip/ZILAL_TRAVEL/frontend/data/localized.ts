import english from "./content/examples-en.json";
import type { PlatformData, Entity } from "@/types/platform";
export function localizedSeed(
  data: PlatformData,
  locale: "ru" | "en",
): PlatformData {
  if (locale === "ru") return data;
  const result = structuredClone(data);
  result.settings = { ...result.settings, ...english.settings };
  for (const [entity, translations] of Object.entries(english.collections)) {
    const key = entity as Entity;
    result.collections[key] = result.collections[key].flatMap((row) => {
      const tr = translations.find((tr) => tr.slug === row.slug);
      return tr
        ? [
            {
              ...row,
              title: tr.title,
              description: tr.description,
              fields: { ...row.fields, ...tr.fields },
            },
          ]
        : [];
    });
  }
  return result;
}
