import { NextRequest, NextResponse } from "next/server";
export function proxy(request: NextRequest) {
  const path = request.nextUrl.pathname;
  const english = path === "/en" || path.startsWith("/en/");
  const inner = english ? path.slice(3) || "/" : path;
  if (
    english &&
    !/^\/(?:$|about\/?$|contacts\/?$|plan\/?$|privacy\/?$|payment\/?$|gallery\/?$|(?:tours|destinations|experiences|journal)(?:\/[^/]+)?\/?$)/.test(
      inner,
    )
  )
    return new NextResponse(null, { status: 404 });
  const headers = new Headers(request.headers);
  headers.set("x-zilal-locale", english ? "en" : "ru");
  headers.set("x-zilal-public-path", path);
  if (english) {
    const url = request.nextUrl.clone();
    url.pathname = inner;
    return NextResponse.rewrite(url, { request: { headers } });
  }
  return NextResponse.next({ request: { headers } });
}
export const config = {
  matcher: ["/((?!api/|_next/|images/|icon.svg|robots.txt|sitemap.xml).*)"],
};
